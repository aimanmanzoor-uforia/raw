# Syncerize — WooCommerce Multi‑Store Inventory Sync

Real‑time multi‑store inventory syncing plugin for WooCommerce.

Syncerize keeps product stock levels in sync across multiple WooCommerce stores and exposes a small REST API surface for secure coordination with the Syncerize cloud.

- Plugin URI: https://syncerize.com/
- Author: Uforia Infotech Inc — https://uforiainfotech.com/
- Requires: WordPress + WooCommerce
- Current version: see `syncerize.php` header

## Features

- Real‑time inventory synchronization between stores
- Lightweight REST API endpoints for token retrieval and utility operations
- Admin menu integration (hidden first Dashboard item for cleaner UI)
- Remote update support via JSON manifest (`PLUGIN_UPDATE_URL`)

## Requirements

- WordPress (tested with recent 6.x)
- WooCommerce (enabled)
- PHP 7.4+ (recommended PHP 8.0+)

## Installation

1. Upload the `syncerize` folder to `wp-content/plugins/` (or install via ZIP).
2. Activate “Syncerize” in WordPress → Plugins.
3. Copy `config.example.php` to `config.php` in the plugin root and adjust values:

```php
return [
    'APP_ID' => 420380673,           // Provided by Syncerize
    'APP_ENV' => 'dev',              // dev | staging | prod
    'APP_URL' => 'https://dev.syncerize.com',
    'PLUGIN_UPDATE_URL' => 'https://syncerize.com/wp-content/uploads/Wordpress/dev/syncerize.json'
];
```

4. Ensure WooCommerce is active and your store URL is reachable from the Syncerize cloud.

## Configuration Notes

- The plugin loads settings from `config.php` at runtime (see `syncerize.php`).
- Remote updates: the updater queries `PLUGIN_UPDATE_URL` for a JSON manifest and compares versions. The package URL should point to a downloadable ZIP.

## REST API

All endpoints are under the namespace `swc/v1`.

- `GET /wp-json/swc/v1/get-token` — Obtain a short‑lived token used by Syncerize services.
- `GET /wp-json/swc/v1/fetch-shop-detail` — Returns basic shop metadata.
- `POST /wp-json/swc/v1/set-store-type-in-woocommerce` — Persist store type settings sent by Syncerize.
- `GET /wp-json/swc/v1/search-customer-by-email?email=...` — Search WooCommerce customers by email.
- `GET /wp-json/swc/v1/search-customer-by-phone?phone=...` — Search WooCommerce customers by phone.
- `GET /wp-json/swc/v1/get-encoded-resource-id?resource_id=...` — Utility to encode a resource id.
- `GET /wp-json/swc/v1/get-decoded-resource-id?code=...` — Utility to decode a resource id.

Refer to `includes/class-general-routes-controller.php` for exact behavior and responses.

## Usage

After activation and configuration:

- Connect your store in the Syncerize dashboard using the token endpoint.
- Manage inventory in any connected store; Syncerize will propagate stock changes.

## Development

- Main plugin bootstrap: `syncerize.php`
- Controllers: `includes/`
- Custom scripts: `js/syncerize-custom.js`
- Hooks and helpers: `hooks.php`, `functions.php`

## Changelog

See `CHANGELOG.md`.

## Support

For assistance, contact the Syncerize team via https://syncerize.com/ or your account representative at Uforia Infotech Inc.

## License

All rights reserved unless otherwise specified by your distribution agreement.