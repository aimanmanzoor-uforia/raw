<?php

namespace Syncerize\WooCommerce;

use Exception;
use stdClass;
use Throwable;
use WP_REST_Controller;
use WC_Product_Query;
use WC_Product_Variation;
use WC_Product_Variable;
use WC_Product_Simple;
use WC_Product_Attribute;

/**
 * Product_Details_Controller class.
 *
 * This class handles the registration of custom REST API routes for retrieving
 * product details and searching products in a WooCommerce store. The routes
 * are registered under the namespace 'swc/v1'.
 */
class Product_Details_Controller extends WP_REST_Controller
{

    /**
     * Registers the routes for the custom REST API endpoints.
     *
     * This function registers two routes:
     * 1. A route for retrieving product details based on an encrypted product
     * ID and user ID.
     * 2. A route for searching products based on a search query, excluding
     * specific product IDs, and a user ID.
     */
    public function register_routes()
    {
        $version   = '1';
        $namespace = 'swc/v' . $version;

        register_rest_route(
            $namespace,
            '/fetch-filtered-products-v2',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'filter_products'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product-ids',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'filter_products'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-filtered-products',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'filter_products'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_product'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-multiple-products',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_multiple_products'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product-metafields',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_product_metafields'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/update-product-metafield',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'update_product_metafield'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/delete-metafields',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'delete_metafields'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product-via-id-check',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'filter_products'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-products-count',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'fetch_products_count'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product-variants-unique-id',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_product_variants_unique_id'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/get-shopify-products',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'filter_products'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/create-product',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'create_product'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/add-tags',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'add_tags'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/create-product-metafield',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'create_product_metafield'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/get-product-variant-metafields',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'get_product_variant_metafields'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/get-product-variants-metafields-by-product',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'get_product_variants_metafields_by_product'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/update-inventory-item',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'update_inventory_item'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/delete-product',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'delete_product'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/search-variants-by-product-id',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'search_variants_by_product_id'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/set-metafields',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'set_metafields'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/set-metafield-definition',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'set_metafield_definition'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/search-products',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'search_products'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product-legacy-resource-id',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_product_legacy_resource_id'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-location-info',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_location_info'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/get-inventory-level',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'get_inventory_level'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-default-location',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_default_location'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product-variants-quantity',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_product_variants_quantity'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/inventory-activate',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'inventory_activate'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/inventory-set-quantities',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'inventory_set_quantities'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/get-product-variant-metafield-by-key',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'get_product_variant_metafield_by_key'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product-images',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_product_images'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/get-product-image-metafields',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'get_product_image_metafields'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/update-product',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'update_product'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/product-variants-bulk-update',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'product_variants_bulk_update'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/create-product-media',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'create_product_media'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product-images-and-media',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_product_images_and_media'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/append-media-to-variants',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'append_media_to_variants'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/detach-media-from-variants',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'detach_media_from_variants'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-product-media',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_product_media'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/product-reorder-media',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'product_reorder_media'],
                'permission_callback' => '__return_true'
            )
        );
    }

    /**
     * This function reorders product media
     *
     * @param $request
     *
     * @return mixed
     */
    public function product_reorder_media($request)
    {
        try {
            $product_id = $request['payload']['id'];
            syncerize_wc_convert_gid_to_id($product_id);
            $product_id = syncerize_wc_decode_resource_id($product_id);

            $product = wc_get_product($product_id);

            $image_ids = [];

            // Traverse image position payload
            foreach ($request['payload']['moves'] as $image) {
                syncerize_wc_convert_gid_to_id($image['id']);
                $image_id = syncerize_wc_decode_resource_id($image['id']);

                // Reorder images
                $image_ids[$image['newPosition']] = $image_id;

                if ($image['newPosition'] == 0) {
                    // Set the image as the product featured image
                    set_post_thumbnail($product_id, $image_id);
                }
            }

            ksort($image_ids);

            $product->set_gallery_image_ids($image_ids);
            $product->save();

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'productReorderMedia' => [
                                'job' => [
                                    'id' => 'gid://woocommerce/Job/' . uniqid()
                                ],
                                'mediaUserErrors' => [],
                                'userErrors' => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function detaches media from variant(s)
     *
     * @param $request
     *
     * @return mixed
     */
    public function fetch_product_media($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);
            $product    = wc_get_product($product_id);


            $image_ids = $this->get_product_image_ids($product);
            $medias    = [];

            // Make and format media data
            foreach ($image_ids as $image_id) {
                $medias[] = [
                    'node' => [
                        'id' => 'gid://woocommerce/MediaImage/' . syncerize_wc_generate_resource_id('media', $image_id),
                        'image' => [
                            'url' => wp_get_attachment_url($image_id)
                        ]
                    ]
                ];
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'product' => [
                                'media' => [
                                    'edges' => $medias
                                ]
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function detaches media from variant(s)
     *
     * @param $request
     *
     * @return mixed
     */
    public function detach_media_from_variants($request)
    {
        try {
            foreach ($request['variantMedia'] as $variantMedia) {
                $variant_id = $variantMedia['variantId'];

                syncerize_wc_convert_gid_to_id($variant_id);
                $variant_id = syncerize_wc_decode_resource_id($variant_id);

                // Deletes variant's featured image
                delete_post_thumbnail($variant_id);
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'productVariantDetachMedia' => [
                                'userErrors' => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function appends media to variant(s)
     *
     * @param $request
     *
     * @return mixed
     */
    public function append_media_to_variants($request)
    {
        try {
            foreach ($request['variantMedia'] as $variantMedia) {
                $media_id = $variantMedia['mediaIds'][0];

                syncerize_wc_convert_gid_to_id($media_id);
                $image_id = syncerize_wc_decode_resource_id($media_id);

                $variant_id = $variantMedia['variantId'];

                syncerize_wc_convert_gid_to_id($variant_id);
                $variant_id = syncerize_wc_decode_resource_id($variant_id);

                // Set the image as the product variant's featured image
                set_post_thumbnail($variant_id, $image_id);
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'productVariantAppendMedia' => [
                                'userErrors' => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function fetches product images and media
     *
     * @param $request
     *
     * @return mixed
     */
    public function fetch_product_images_and_media($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);
            $product    = wc_get_product($product_id);

            // Extract query media ids
            preg_match_all('/id:(\d+)/', $request['searchQuery'], $media_ids);
            $media_ids = $media_ids[1];

            if (!$product) {
                $productBody = [
                    'product' => null
                ];
            } else {
                $images = [];
                $medias = [];

                $gallery_image_ids          = $product->get_gallery_image_ids();
                $gallery_image_ids_reversed = array_reverse($gallery_image_ids);

                // Traverse gallery images reversed to get the latest images
                foreach ($gallery_image_ids_reversed as $key => $gallery_image_id) {
                    // Append image
                    $images[] = [
                        'node' => [
                            'id' => 'gid://woocommerce/ProductImage/' . syncerize_wc_generate_resource_id(
                                    'image',
                                    $gallery_image_id
                                ),
                            'url' => wp_get_attachment_url($gallery_image_id)
                        ]
                    ];

                    // If total records are reached
                    if (($key + 1) == $request['totalRecords']) {
                        break;
                    }
                }

                $counter = 0;

                foreach ($gallery_image_ids as $gallery_image_id) {
                    // If total records are reached
                    if ($counter == $request['totalRecords']) {
                        break;
                    }

                    $media_id = syncerize_wc_generate_resource_id('media', $gallery_image_id);

                    // If media id is in the query media ids
                    if (in_array($media_id, $media_ids)) {
                        // Append media
                        $medias[] = [
                            'node' => [
                                'id' => 'gid://woocommerce/MediaImage/' . $media_id,
                                'image' => [
                                    'url' => wp_get_attachment_url($gallery_image_id)  // Get the image alt text
                                ]
                            ]
                        ];

                        $counter++;
                    }
                }

                $productBody = [
                    'product' => [
                        'images' => [
                            'edges' => $images
                        ],
                        'media' => [
                            'edges' => $medias
                        ]
                    ]
                ];
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => $productBody
                    ],
                    'mediaIds' => $media_ids,
                    'searchQuery' => $request['searchQuery']
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function creates product media
     *
     * @param $request
     *
     * @return mixed
     */
    public function create_product_media($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);
            $product    = wc_get_product($product_id);
            $image_url  = $request['image']['originalSource'];

            // Use WP-native download and sideload to handle redirects/SSL and file validation
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';

            // 1) Try the robust WordPress download helper to a temp file
            $tmp_file = download_url($image_url);

            // 2) If download_url fails, fall back to wp_remote_get with a browser-like UA and stream to temp
            if (is_wp_error($tmp_file)) {
                $response = wp_remote_get($image_url, [
                    'timeout'      => 20,
                    'redirection'  => 5,
                    'headers'      => [
                        // Some CDNs block default PHP UA; mimic a common browser
                        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
                    ],
                ]);

                if (is_wp_error($response)) {
                    throw new Exception('Failed to download image: ' . $response->get_error_message());
                }

                $code = wp_remote_retrieve_response_code($response);
                if ($code < 200 || $code >= 300) {
                    throw new Exception('Failed to download image: HTTP ' . $code);
                }

                $body = wp_remote_retrieve_body($response);
                if ($body === '' || $body === null) {
                    throw new Exception('Failed to download image: empty response body');
                }

                $tmp_file = wp_tempnam($image_url);
                if (!$tmp_file) {
                    throw new Exception('Failed to create temp file for image');
                }
                if (file_put_contents($tmp_file, $body) === false) {
                    @unlink($tmp_file);
                    throw new Exception('Failed to write image to temp file');
                }
            }

            // Derive a clean filename without query string
            $path_part = parse_url($image_url, PHP_URL_PATH);
            $file_name = basename($path_part ?: 'image');
            [$file_name] = explode('?', $file_name);
            $file_name = sanitize_file_name($file_name);

            // Prepare file array for media_handle_sideload
            $file_array = [
                'name'     => $file_name,
                'tmp_name' => $tmp_file,
            ];

            // Sideload into media library attached to product
            $image_id = media_handle_sideload($file_array, $product_id);

            if (is_wp_error($image_id)) {
                @unlink($tmp_file);
                throw new Exception('Failed to insert attachment: ' . $image_id->get_error_message());
            }

            $gallery_image_ids_count = count($product->get_gallery_image_ids());

            // In case no gallery image is found, set the image as the product's featured image
            if ($gallery_image_ids_count == 0) {
                // Set the image as the product's featured image
                set_post_thumbnail($product_id, $image_id);
            }

            // Add image in product gallery's specific position
            $this->set_image_in_product_gallery($product, $gallery_image_ids_count, $image_id);

            return rest_ensure_response(
                [
                    'errors' => false,
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'productCreateMedia' => [
                                'media' => [
                                    [
                                        'id' => 'gid://woocommerce/MediaImage/' . syncerize_wc_generate_resource_id(
                                                'media',
                                                $image_id
                                            ),
                                    ]
                                ],
                                'mediaUserErrors' => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function bulk updates variant(s) regular
     * and sale price of a product
     *
     *
     * @param $request
     *
     * @return mixed
     */
    public function product_variants_bulk_update($request)
    {
        try {
            foreach ($request['variants'] as $variant) {
                syncerize_wc_convert_gid_to_id($variant['id']);

                $variant_id = syncerize_wc_decode_resource_id($variant['id']);

                $product_variant = wc_get_product($variant_id);

                $product_variant->set_regular_price($variant['price'] ?: '0.00');
                $product_variant->set_sale_price('');

                $product_variant->save();
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'productVariantsBulkUpdate' => [
                                'product' => [
                                    'id' => 'gid://woocommerce/Product/' . $request['productId']
                                ]
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function returns a generic products response
     * skeleton
     *
     * @return array
     */
    private function get_products_response_skeleton(): array
    {
        return [
            'errors' => false,
            'response' => new stdClass(),
            'status' => 200,
            'body' => [
                'data' => [
                    'products' => [
                        'edges' => [

                        ],
                        'pageInfo' => [
                            'hasNextPage' => false,
                            'hasPreviousPage' => false,
                        ]
                    ],
                ]
            ]
        ];
    }

    /**
     * This function sets has next/previous page
     *
     * @param $limit
     * @param $page
     * @param $response
     * @param $product_count
     */
    private function set_has_page($limit, $page, &$response, $product_count)
    {
        // Check if next page exists
        if ($product_count > ($limit * $page)) {
            $response['body']['data']['products']['pageInfo']['hasNextPage'] = true;
        }

        // Check if previous page exists
        if ($page > 1) {
            $response['body']['data']['products']['pageInfo']['hasPreviousPage'] = true;
        }
    }

    /**
     * This function sets filter arguments
     *
     * @param $product_query_args
     * @param $request
     *
     * @return bool
     */
    private function set_products_filter_args(&$product_query_args, $request): bool
    {
        if (isset($request['query'])) {
            // Check if query has keyword filter
            if (strpos($request['query'], 'title') !== false) {
                [, $product_query_args['s']] = explode('*', $request['query']);
            }

            // Check if query has individual product(s)
            if (preg_match_all('/id:(\d+)/', $request['query'], $matches) > 0) {
                $product_query_args['include'] = array_map('syncerize_wc_decode_resource_id', $matches[1]);
            } elseif (preg_match_all('/-(\d+)/', $request['query'], $matches) > 0) {
                $product_query_args['exclude'] = array_map('syncerize_wc_decode_resource_id', $matches[1]);
            } elseif (strpos($request['query'], "id:'')") !== false) {
                return false;
            }

            // Check if query has included tags filter
            if (strpos($request['query'], 'tag') !== false) {
                $filter_type = 'tag';

                // Check if query has excluded tags filter
                if (strpos($request['query'], '-tag') !== false) {
                    $filter_type = '-tag';
                }

                [, $string] = explode("$filter_type:'", $request['query']);

                [$tag] = explode("'", $string);

                $product_query_args['tax_query'] = [
                    [
                        'taxonomy' => 'product_tag',
                        'field' => 'slug',
                        'terms' => [$tag]
                    ]
                ];

                if ($filter_type == '-tag') {
                    $product_query_args['tax_query'][0]['operator'] = 'NOT IN';
                }
            }
        }

        return true;
    }

    /**
     * Add Variant id, barcode and sku
     * for response
     *
     * @param $product
     * @param $response
     * @param $key
     * @param $index
     */
    private function add_variant_attributes($product, &$response, $key, $index)
    {
        $response['body']['data']['products']['edges'][$key]['node']['variants']['edges'][$index]['node']['id']      = syncerize_wc_generate_resource_id(
            'variant',
            $product->get_id()
        );
        $response['body']['data']['products']['edges'][$key]['node']['variants']['edges'][$index]['node']['sku']     = $product->get_sku(
        );
        $response['body']['data']['products']['edges'][$key]['node']['variants']['edges'][$index]['node']['barcode'] = get_post_meta(
            $product->get_id(),
            '_global_unique_id',
            true
        );
    }

    /**
     * This function retrieves product(s) and retrieves
     * them in graphql style
     *
     * @param $request
     * @return mixed
     */
    public function filter_products($request)
    {
        try {
            // Create response skeleton
            $response = $this->get_products_response_skeleton();

            $product_query_args = [
                'status' => 'publish',
                'limit' => $request['perPage'],
                'page' => $request['page'] ?? 1,
                'orderby' => 'title',
                'paginate' => true,
                'order' => 'ASC',
            ];

            // Set filter argument(s)
            if (!$this->set_products_filter_args($product_query_args, $request)) {
                // no product found
                return rest_ensure_response($response);
            }

            // Retrieve products
            $products_query = new WC_Product_Query($product_query_args);
            $query_results  = $products_query->get_products();
            $products       = $query_results->products;

            // Set has next/previous page response attributes
            $this->set_has_page($request['perPage'], $request['page'], $response, $query_results->total);


            foreach ($products as $key => $product) {
                $product_id = syncerize_wc_generate_resource_id('product', $product->get_id());

                if ($request['function_name'] == 'getShopifyProducts') {
                    // Add product id to response
                    $response['body']['data']['products']['edges'][] = [
                        'cursor' => true,
                        'node' => [
                            'legacyResourceId' => $product_id,
                            'storeProductType' => $product->get_type()
                        ]
                    ];

                    $variant_ids = $product->get_children();

                    if ($variant_ids && $product->get_type() == 'variable') {
                        foreach ($variant_ids as $index => $variant_id) {
                            $variation = new WC_Product_Variation($variant_id);

                            // Add variant to response
                            $this->add_variant_attributes($variation, $response, $key, $index);
                        }
                    } else {
                        // Add self variant to response
                        $this->add_variant_attributes($product, $response, $key, 0);
                    }
                } else {
                    // Add product id to response
                    $response['body']['data']['products']['edges'][] = [
                        'cursor' => true,
                        'node' => [
                            'id' => "gid://woocommerce/Product/$product_id"
                        ]
                    ];

                    if ($request['function_name'] == 'fetchFilteredProducts' ||
                        $request['function_name'] == 'fetchProductViaIdCheck' ||
                        $request['function_name'] == 'fetchFilteredProductsV2') {
                        // Get featured image
                        $featured_image = $this->get_featured_image_src($product);

                        if ($featured_image) {
                            $featured_image = [
                                'thumbnail' => $featured_image
                            ];
                        }

                        // Add product attributes to response
                        $response['body']['data']['products']['edges'][$key]['node']['title']         = $product->get_name(
                        );
                        $response['body']['data']['products']['edges'][$key]['node']['featuredImage'] = $featured_image;
                        $response['body']['data']['products']['edges'][$key]['node']['variantsCount'] = [
                            'count' => $product->get_children() ? count($product->get_children()) : 1
                        ];

                        if ($request['function_name'] == 'fetchFilteredProducts') {
                            $response['body']['data']['products']['edges'][$key]['node']['storeProductType'] = $product->get_type(
                            );
                        }

                        if ($request['function_name'] == 'fetchFilteredProductsV2' ||
                            $request['function_name'] == 'fetchProductViaIdCheck') {
                            // Add product attributes to response
                            $response['body']['data']['products']['edges'][$key]['node']['status']         = 'ACTIVE';
                            $response['body']['data']['products']['edges'][$key]['node']['totalInventory'] = $product->get_stock_quantity(
                                ) ?? 0;
                        }

                        if ($request['function_name'] == 'fetchProductViaIdCheck') {
                            $response['body']['data']['products']['edges'][$key]['node']['productCategory'] = [
                                'productTaxonomyNode' => [
                                    'name' => $this->get_product_category($product->get_id())
                                ]
                            ];
                        }
                    }
                }
            }

            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function retrieves products count and retrieves
     * them in graphql style
     *
     * @param $request
     * @return mixed
     */
    public function fetch_products_count($request)
    {
        try {
            // Create response skeleton
            $response = [
                'errors' => false,
                'response' => new stdClass(),
                'status' => 200,
                'body' => [
                    'data' => [
                        'productsCount' => [
                            'count' => 0
                        ],
                    ]
                ]
            ];

            $product_query_args = [
                'status' => 'publish',
                'limit' => -1
            ];

            // Set filter argument(s)
            if (!$this->set_products_filter_args($product_query_args, $request)) {
                // no product found
                return rest_ensure_response($response);
            }

            // Retrieve products
            $products_query = new WC_Product_Query($product_query_args);
            $query_results  = $products_query->get_products();

            // Count the number of products
            $response['body']['data']['productsCount']['count'] = count($query_results);


            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function retrieves product category name
     *
     * @param $product_id
     * @return string
     */
    private function get_product_category($product_id): string
    {
        $categories = get_the_terms($product_id, 'product_cat');

        if (!empty($categories) && !is_wp_error($categories)) {
            foreach ($categories as $category) {
                if ($category->name !== 'Uncategorized') {
                    return $category->name; // Output the name of the first category that isn’t "Uncategorized"
                }
            }
        }

        return 'Uncategorized';
    }

    /**
     * This function retrieves product's featured image
     *
     * @param $product
     * @return array|null
     */
    private function get_featured_image_src($product): ?string
    {
        return wp_get_attachment_url($product->get_image_id()) ?: null;
    }

    /**
     * This function retrieves product's featured image
     *
     * @param $image_id
     * @return array|null
     */
    private function get_image_src($image_id): ?string
    {
        return wp_get_attachment_url($image_id) ?: null;
    }

    /**
     * Get product image metadata
     *
     * @param $image_id
     *
     * @return array|null
     */
    private function get_product_image_metadata($image_id): ?array
    {
        // Get the image metadata (width, height, etc.)
        $image_meta = wp_get_attachment_metadata($image_id);

        if (!$image_meta) {
            return null;
        }

        return [
            'altText' => get_post_meta($image_id, '_wp_attachment_image_alt', true),
            'width' => $image_meta['width'],
            'height' => $image_meta['height'],
            'url' => $this->get_image_src($image_id)
        ];
    }

    /**
     * This function retrieves product variant(s)
     * in graphql format for single product
     *
     *
     * @param $product
     * @return array
     */
    private function get_product_variants($product): array
    {
        $variations    = $product->get_children();
        $variants_data = [];

        $weight_units = [
            'kg' => 'KILOGRAMS',
            'lbs' => 'POUNDS',
            'oz' => 'OUNCES',
            'g' => 'GRAMS'
        ];

        if ($variations) {
            $variantsAttribute = [];

            // Get and sort product attributes by position
            $product_attributes = $product->get_attributes();

            uasort($product_attributes, function ($a, $b) {
                return $a->get_position() <=> $b->get_position();
            });

            foreach ($variations as $key => $id) {
                $variant = new WC_Product_Variation($id);

                $variant_attributes = $variant->get_attributes();

                // Build ordered variant title
                $ordered_values = [];

                foreach ($product_attributes as $attribute_name => $product_attribute) {

                    $value = null;

                    if (isset($variant_attributes['attribute_' . $attribute_name])) {
                        $value = $variant_attributes['attribute_' . $attribute_name];
                    } elseif (isset($variant_attributes[$attribute_name])) {
                        $value = $variant_attributes[$attribute_name];
                    }

                    if (!empty($value)) {
                        $ordered_values[] = $value;
                    }
                }

                $variantAttribute = implode(' / ', $ordered_values);

                // Skip duplicate variants (only when attributes exist)
                if (in_array($variantAttribute, $variantsAttribute) && !empty($variantAttribute)) {
                    continue;
                }

                $variantsAttribute[] = $variantAttribute;

                // Get variant featured image if found
                $image = $variant->get_data()['image_id'] ? [
                    'id' => syncerize_wc_generate_resource_id('image', $variant->get_image_id())
                ] : null;

                $variant_id = syncerize_wc_generate_resource_id('variant', $id);

                $variant_data = [
                    'node' => [
                        'id' => $variant_id,
                        'title' => $variantAttribute,
                        'price' => $variant->get_price() ?: '0.00',
                        'taxable' => true,
                        'position' => $key + 2,
                        'inventoryPolicy' => 'DENY',
                        'compareAtPrice' => null,
                        'sku' => get_post_meta($id, '_sku', true),
                        'barcode' => get_post_meta($id, '_global_unique_id', true),
                        'createdAt' => $variant->get_date_created()->date('Y-m-d H:i:s'),
                        'updatedAt' => $variant->get_date_modified()->date('Y-m-d H:i:s'),
                        'image' => $image,
                        'inventoryItem' => [
                            'id' => $variant_id,
                            'tracked' => get_post_meta($id, '_manage_stock', true) == "yes",
                            'requiresShipping' => $variant->needs_shipping(),
                            'measurement' => [
                                'weight' => [
                                    'unit' => $weight_units[get_option('woocommerce_weight_unit')],
                                    'value' => (float) $variant->get_weight()
                                ]
                            ],
                            'countryCodeOfOrigin' => WC()->countries->get_base_country(),
                            'harmonizedSystemCode' => null
                        ],
                        'inventoryQuantity' => $variant->get_stock_quantity() ?? 0,
                        'selectedOptions' => []
                    ]
                ];

                // Build selectedOptions in correct order
                foreach ($product_attributes as $attribute_name => $product_attribute) {

                    $value = null;

                    if (isset($variant_attributes['attribute_' . $attribute_name])) {
                        $value = $variant_attributes['attribute_' . $attribute_name];
                    } elseif (isset($variant_attributes[$attribute_name])) {
                        $value = $variant_attributes[$attribute_name];
                    }

                    if (empty($value)) {
                        continue;
                    }

                    $variant_data['node']['selectedOptions'][] = [
                        'name'  => wc_attribute_label($attribute_name),
                        'value' => $value
                    ];
                }

                $variants_data[] = $variant_data;
            }
        } else {
            $variants_data[] = $this->get_self_variant($weight_units, $product);
        }

        return ['edges' => $variants_data];
    }

    /**
     * This function is used to retrieve product self variant
     *
     * @param $weight_units
     * @param $product
     *
     * @return array[]
     */
    private function get_self_variant($weight_units, $product): array
    {
        // Self Variant
        $variant_id = syncerize_wc_generate_resource_id('variant', $product->get_id());

        // Get product featured image if found
        $image = $product->get_image_id() ? [
            'id' => syncerize_wc_generate_resource_id('image', $product->get_image_id())
        ] : null;

        return [
            'node' => [
                'id' => $variant_id,
                'title' => 'Default Title',
                'price' => $product->get_price() ?: '0.00',
                'taxable' => true,
                'position' => 1,
                'inventoryPolicy' => 'DENY',
                'compareAtPrice' => null,
                'sku' => get_post_meta($product->get_id(), '_sku', true),
                'barcode' => get_post_meta($product->get_id(), '_global_unique_id', true),
                'selectedOptions' => [
                    [
                        'name' => 'Title',
                        'value' => 'Default Title'
                    ]
                ],
                'createdAt' => $product->get_date_created()->date('Y-m-d H:i:s'),
                'updatedAt' => $product->get_date_modified()->date('Y-m-d H:i:s'),
                'image' => $image,
                'inventoryItem' => [
                    'id' => $variant_id,
                    'tracked' => get_post_meta($product->get_id(), '_manage_stock', true) == "yes",
                    'requiresShipping' => $product->needs_shipping(),
                    'measurement' => [
                        'weight' => [
                            'unit' => $weight_units[get_option('woocommerce_weight_unit')],
                            'value' => (float)$product->get_weight()
                        ]
                    ],
                    'countryCodeOfOrigin' => WC()->countries->get_base_country(),
                    'harmonizedSystemCode' => null
                ],
                'inventoryQuantity' => $product->get_stock_quantity() ?? 0
            ]
        ];
    }

    /**
     * This function retrieves product image(s)
     * in graphql format for single product
     *
     * @param $product
     * @param string $type
     *
     * @return array
     */
    private function get_product_images($product, $type = 'images'): array
    {
        $image_ids = [];

        // Add product image id if found
        if ($product->get_image_id()) {
            $image_ids[] = $product->get_image_id();
        }

        if ($product->is_type('variable')) {
            $variantIds = $product->get_children();

            foreach ($variantIds as $variantId) {
                $variant = new WC_Product_Variation($variantId);

                // Add variant image id if found
                if ($variant->get_image_id()) {
                    $image_ids[] = $variant->get_image_id();
                }
            }
        }

        // Append gallery images if any
        if ($product->get_gallery_image_ids()) {
            array_push($image_ids, ...$product->get_gallery_image_ids());
        }

        $image_ids = array_unique($image_ids);

        $images = [
            'edges' => []
        ];

        foreach ($image_ids as $image_id) {
            $image_metadata = $this->get_product_image_metadata($image_id);

            // Skip image meta data not found
            if (!$image_metadata) {
                continue;
            }

            if ($type == 'images') {
                $images['edges'][] = [
                    'node' => [
                        'id' => syncerize_wc_generate_resource_id('image', $image_id),
                        'height' => $image_metadata['height'],
                        'width' => $image_metadata['width'],
                        'url' => $this->get_image_src($image_id),
                        'altText' => $image_metadata['altText']
                    ]
                ];
            } else {
                $images['edges'][] = [
                    'node' => [
                        'id' => syncerize_wc_generate_resource_id('media', $image_id),
                        'image' => [
                            'url' => $this->get_image_src($image_id)
                        ]
                    ]
                ];
            }
        }

        return $images;
    }

    /**
     * This function sets product type for response
     *
     * @param $product
     *
     * @param $response
     */
    public function set_response_custom_fields($product, &$response)
    {
        $response['hasVariation'] = false;
        $response['type']         = $product->get_type();

        if ($product->get_children()) {
            $response['hasVariation'] = true;
        } elseif ($product->get_type() != 'variable' &&
            $product->get_type() != 'simple') {
            $response['type'] = 'simple';
        }
    }

    /**
     * This function formats fetched product
     *
     * @param $product
     * @param $show_metafields
     *
     * @return array[]
     */
    public function format_fetched_product($product, $show_metafields): array
    {
        $product_tags = wp_get_post_terms($product->get_id(), 'product_tag', ['fields' => 'names']);

        // Filter out tags without letters or numbers
        $product_tags = array_filter(
            $product_tags,
            function ($tag) {
                return preg_match('/[a-zA-Z]/', $tag) || preg_match('/[0-9]/', $tag);
            }
        );

        $options = [];

        $index = 0;

        if ($product->get_children()) {
            // Get attributes used as variations
            $attributes = $product->get_variation_attributes();

            // Limit attributes to first 3 (Shopify allows max 3 options)
//            $attributes = array_slice($attributes, 0, 3, true);

            foreach ($attributes as $key => $values) {
                $option_id = $product->get_id() . $index;

                $options[] = [
                    'id' => syncerize_wc_generate_resource_id('option', $option_id),
                    'name' => $key,
                    'position' => ($index + 1),
                    'values' => $values
                ];

                $index++;
            }
        } else {
            $option_id = $product->get_id() . $index;

            // Default Option
            $options[] = [
                'id' => syncerize_wc_generate_resource_id('option', $option_id),
                'name' => 'Title',
                'position' => 1,
                'values' => [
                    'Default Title'
                ]
            ];
        }

        $featuredImageMetaData = $this->get_product_image_metadata($product->get_image_id());

        $image_id = syncerize_wc_generate_resource_id('image', $product->get_image_id());

        // If featured image exists
        if ($featuredImageMetaData) {
            $featuredImageMetaData = [
                'id' => $image_id,
                'url' => $this->get_featured_image_src($product),
                'width' => $featuredImageMetaData['width'],
                'height' => $featuredImageMetaData['height'],
                'altText' => $featuredImageMetaData['altText']
            ];
        }

        $product_id = syncerize_wc_generate_resource_id('product', $product->get_id());

        $formatted_product = [
            'id' => $product_id,
            'title' => $product->get_title(),
            'status' => ($product->get_status() == 'publish') ? 'ACTIVE' : 'DRAFT',
            'descriptionHtml' => $product->get_description(),
            'tags' => $product_tags,
            'productType' => '',
            'handle' => '',
            'createdAt' => $product->get_date_created()->date('Y-m-d H:i:s'),
            'updatedAt' => syncerize_wc_get_object_modified_at_datetime_in_utc($product),
            'vendor' => '',
            'options' => $options,
            'featuredImage' => $featuredImageMetaData,
            'variants' => $this->get_product_variants($product),
            'images' => $this->get_product_images($product),
            'media' => $this->get_product_images($product, 'media'),
            'updated_at' => syncerize_wc_get_object_modified_at_datetime_in_utc($product)
        ];

        if ($show_metafields) {
            $formatted_product['metafields'] = $this->get_product_metafields($product);
        }

        return $formatted_product;
    }

    /**
     * This function is used to retrieve a single product
     *
     * @param $request
     *
     * @return WP_REST_Response|WP_Error
     */
    public function fetch_product($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);

            // Retrieve product
            $product = wc_get_product($product_id);

            // Create response skeleton
            $response = [
                'errors' => false,
                'response' => new stdClass(),
                'status' => 200,
                'body' => [
                    'container' => [
                        'data' => ['product' => $this->format_fetched_product($product, $request['metafields'])],
                    ]

                ]
            ];

            $this->set_response_custom_fields($product, $response);

            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function is used to retrieve multiple products
     *
     * @return mixed
     */
    public function fetch_multiple_products($request)
    {
        try {
            preg_match_all('/id:(\d+)/', $request['searchQuery'], $product_ids);
            $product_ids = $product_ids[1];
            $product_ids = array_map('syncerize_wc_decode_resource_id', $product_ids);

            $products = wc_get_products(
                [
                    'include' => $product_ids,
                    'limit' => $request['perPage']
                ]
            );

            $formattedProducts = [];

            foreach ($products as $product) {
                $formattedProducts[] = [
                    'node' => ['container' => $this->format_fetched_product($product, $request['metafields'])]
                ];
            }

            // Create response skeleton
            $response = [
                'errors' => false,
                'response' => new stdClass(),
                'status' => 200,
                'body' => [
                    'data' => [
                        'products' => ['edges' => $formattedProducts]
                    ]
                ]
            ];

            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function retrieves metafield id
     *
     * @param $product_id
     * @param $key
     *
     * @return string
     */
    private function get_metafield_id($product_id, $key): string
    {
        global $wpdb;

        $metafield_id = $wpdb->get_var(
            $wpdb->prepare(
                "
                        SELECT meta_id
                        FROM $wpdb->postmeta
                        WHERE
                        post_id = %d
                        AND meta_key = %s
                        LIMIT 1
                    ",
                $product_id,
                $key
            )
        );

        return syncerize_wc_generate_resource_id('metafield', $metafield_id);
    }

    /**
     * This function retrieves product metafield(s)
     *
     * @param $request
     * @return WP_REST_Response|WP_Error
     */
    public function fetch_product_metafields($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);
            $product = wc_get_product($product_id);

            $metafields = $this->get_product_metafields($product);

            return rest_ensure_response(
                [
                    "errors" => false,
                    "response" => [],
                    "status" => 200,
                    "body" => [
                        'data' => [
                            'product' => [
                                'legacyResourceId' => $request['productId'],
                                "metafields" => $metafields
                            ]
                        ]
                    ],
                    "link" => null,
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function is used get woo custom fields
     *
     * @param $product
     *
     * @return array|array[]
     */
    private function get_product_metafields($product)
    {
        $metafields    = ['nodes' => []];
        $custom_fields = get_post_meta($product->get_id()) ?? [];
        $counter       = 0;

        foreach ($custom_fields as $key => $custom_field) {
            // @TODO: Get Custom fields properly
            // to exclude pre-defined meta data
            if (substr($key, 0, 1) !== '_') {
                $metafield_id = $this->get_metafield_id($product->get_id(), $key);

                $metafields['nodes'][] = [
                    'legacyResourceId' => $metafield_id,
                    'namespace' => 'syncerize',
                    'key' => $key,
                    'type' => 'single_line_text_field',
                    'value' => $custom_field[0],
                    'createdAt' => $product->get_date_created()->date('c'),
                    'updatedAt' => $product->get_date_modified()->date('c'),
                    'description' => null,
                ];

                $counter++;

                // Require first 50 metafields
                if ($counter == 50) {
                    break;
                }
            }
        }

        return $metafields;
    }

    /**
     * This function retrieves the first 2 product variant(s)
     *
     * @param $request
     *
     * @return mixed
     */
    public function fetch_product_variants_unique_id($request)
    {
        try {
            $response = [
                'errors' => false,
                'response' => [],
                'status' => 200,
                'body' => [
                    'container' => [
                        'data' => [
                            'productVariants' => [
                                'edges' => []
                            ]
                        ]
                    ]
                ]
            ];

            // Check primary unique identifier
            if (!empty($request['code'])) {
                if ($request['uniqueId'] == 'sku') {
                    if (wc_get_product_id_by_sku($request['code'])) {
                        $response['body']['container']['data']['productVariants']['edges'][] = $request['code'];

                        // Add extra field in response
                        $response['identifier'] = $request['uniqueId'];
                    }
                } else {
                    if (syncerize_wc_get_product_id_by_barcode($request['code'])) {
                        $response['body']['container']['data']['productVariants']['edges'][] = $request['code'];
                        $response['identifier']                                              = $request['uniqueId'];
                    }
                }
            }

            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function retrieves get product id by unique identifier
     * function name
     *
     * @param $unique_identifier
     *
     * @return string
     */
    private function get_product_id_by_unique_identifier_function_name($unique_identifier): string
    {
        if ($unique_identifier == 'sku') {
            return "wc_get_product_id_by_sku";
        } else {
            return "syncerize_wc_get_product_id_by_barcode";
        }
    }

    /**
     * This function checks if a unique identifier exists
     * in any product or not
     *
     * @throws Exception
     */
    private function check_if_unique_identifier_exist($unique_identifier, $variants)
    {
        foreach ($variants as $variant) {
            if (empty($variant[$unique_identifier])) {
                continue;
            }

            $get_product_id_by_unique_identifier = $this->get_product_id_by_unique_identifier_function_name(
                $unique_identifier
            );

            if ($get_product_id_by_unique_identifier($variant[$unique_identifier])) {
                throw new Exception($unique_identifier, 1013);
            }
        }
    }

    /**
     * This function checks if any unique identifier exists
     * in any product or not
     *
     * @param $variants
     *
     * @throws Exception
     */
    private function check_if_all_unique_identifiers_exist($variants)
    {
        $this->check_if_unique_identifier_exist('sku', $variants);
        $this->check_if_unique_identifier_exist('barcode', $variants);
    }

    /**
     * This function is used to create a product
     *
     * @param $request
     * @return mixed
     */
    public function create_product($request)
    {
        try {
            $client_product = null;
            $vendor_product = $request['bulkProdData']['prod']['product'];

            // Check if any duplicate unique identifier exists
            $this->check_if_all_unique_identifiers_exist($vendor_product['variants']);

            // Check if the product is a variable product
            // And if source platform is shopify then it shouldn't have more than 1 variant
            if ($vendor_product['type'] == 'variable' &&
                $vendor_product['hasVariation'] &&
                !($vendor_product['platform'] == 'shopify'
                    && count($vendor_product['variants']) == 1)) {
                // Create a variable product
                $client_product = new WC_Product_Variable();
                $client_product->set_name($vendor_product['title']);
                $client_product->set_description($vendor_product['body_html']);

                $client_product->save();
            } else {
                // In case of source platform shopify always create a simple product
                $type = ($vendor_product['platform'] == 'shopify') ? 'simple' : $vendor_product['type'];

                $wc_product = "WC_Product_".ucfirst($type);

                // Create a single simple/variation product
                $client_product = new $wc_product();
                $client_product->set_name($vendor_product['title']);
                $client_product->set_description($vendor_product['body_html']);

                $selfVariant = $vendor_product['variants'][0];

                $client_product->set_regular_price($selfVariant['price'] ?: '0.00');
                $client_product->set_sale_price('');

                $client_product->set_sku($selfVariant['sku']);

                if (syncerize_wc_is_barcode_format_compatible($selfVariant['barcode'])) {
                    $client_product->update_meta_data('_global_unique_id', $selfVariant['barcode']);
                }

                $client_product->set_manage_stock(true);
                $client_product->set_stock_quantity($selfVariant['inventory_quantity']);

                $weight = $this->convert_weight((double)$selfVariant['weight'], $selfVariant['weight_unit']);
                $client_product->set_weight($weight);

                $client_product->save();

                // Set Metafields
                foreach ($selfVariant['metafields'] as $metafield) {
                    $this->set_reserved_namespace_key($metafield['namespace'], $metafield['key']);

                    update_post_meta($client_product->get_id(), $metafield['key'], $metafield['value']);
                }
            }

            wp_set_object_terms($client_product->get_id(), explode(",", $vendor_product['tags']), 'product_tag');

            // Create syncerize id custom field
            update_post_meta(
                $client_product->get_id(),
                '_syncerize_id',
                syncerize_wc_generate_resource_id('product', $client_product->get_id())
            );

            $client_product_attributes = [];

            if (isset($vendor_product['options'])) {
                // Add product attributes (used for variations)
                foreach ($vendor_product['options'] as $option) {
                    $attribute = new WC_Product_Attribute();
                    $attribute->set_name(sanitize_title($option['name']));
                    $attribute->set_options($option['values']);

                    $attribute->set_visible(true);

                    if ($vendor_product['type'] == 'variable') {
                        $attribute->set_variation(true);
                    }

                    // Add each attribute to the product's attribute array
                    $client_product_attributes[] = $attribute;
                }

                // Set all attributes to the product at once
                $client_product->set_attributes($client_product_attributes);
                $client_product->save();
            }

            if ($vendor_product['type'] == 'variable' &&
                $vendor_product['hasVariation'] &&
                !($vendor_product['platform'] == 'shopify' && count($vendor_product['variants']) == 1)) {
                // Create variations
                foreach ($vendor_product['variants'] as $variant) {
                    $variation = new WC_Product_Variation();
                    $variation->set_parent_id($client_product->get_id());

                    $variation->set_regular_price($variant['price'] ?: '0.00');
                    $variation->set_sale_price('');

                    $variation->set_sku($variant['sku']);

                    $variation->set_manage_stock(true);
                    $variation->set_stock_quantity($variant['inventory_quantity']);

                    if (syncerize_wc_is_barcode_format_compatible($variant['barcode'])) {
                        $variation->update_meta_data('_global_unique_id', $variant['barcode']);
                    }

                    $weight = $this->convert_weight((double)$variant['weight'], $variant['weight_unit']);
                    $variation->set_weight($weight);

                    $attributes = [];
                    foreach ($vendor_product['options'] as $key => $option) {
                        $option_key = "option" . ($key + 1);

                        if (in_array($variant[$option_key], $option['values'])) {
                            $attribute_slug              = sanitize_title($option['name']);
                            $attributes[$attribute_slug] = $variant[$option_key];
                        }
                    }

                    $variation->set_attributes($attributes);

                    // Save the variation
                    $variation->save();

                    // Save syncerize id in post meta data
                    $variant_id = syncerize_wc_generate_resource_id('variant', $variation->get_id());
                    update_post_meta($variation->get_id(), '_syncerize_id', $variant_id);

                    // Set Metafields
                    foreach ($variant['metafields'] as $metafield) {
                        $this->set_reserved_namespace_key($metafield['namespace'], $metafield['key']);

                        update_post_meta($variation->get_id(), $metafield['key'], $metafield['value']);
                    }
                }
            }

            $client_product_id = syncerize_wc_generate_resource_id('product', $client_product->get_id());

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'product' => [
                            'id' => $client_product_id,
                            'title' => $client_product->get_title(),
                            'body_html' => $client_product->get_description(),
                            'vendor' => $vendor_product['vendor'],
                            'product_type' => $vendor_product['product_type'],
                            'created_at' => $client_product->get_date_created()->date('c'),
                            'handle' => $vendor_product['handle'] ?? '',
                            'updated_at' => $client_product->get_date_created()->date('c'),
                            'published_at' => $client_product->get_date_created()->date('c'),
                            'template_suffix' => null,
                            'published_scope' => 'web',
                            "admin_graphql_api_id" => "gid://woocommerce/Product/$client_product_id",
                            'tags' => implode(
                                ",",
                                wp_get_post_terms($client_product->get_id(), 'product_tag', ['fields' => 'names'])
                            ),
                            'status' => 'active',
                            'variants' => $this->get_variants_for_create_product_response($client_product),
                            'options' => $this->get_product_options($client_product),
                            'images' => [],
                            'image' => null
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {

            if ($client_product) {
                $product_id = syncerize_wc_generate_resource_id('product', $client_product->get_id());
                $this->delete_product(['productId' => $product_id]);
            }

            return rest_ensure_response(
                [
                    'errors' => true,
                    'status' => 500,
                    'exception' => [
                        'message' => $exception->getMessage(),
                        'code' => $exception->getCode(),
                        'file' => $exception->getFile(),
                        'line' => $exception->getLine(),
                        'trace' => $exception->getTraceAsString()
                    ]
                ]
            );
        }
    }

    /**
     * This function is used to add tags to a product
     *
     * @param $request
     *
     * @return array
     */
    public function add_tags($request)
    {
        try {
            $product_id = $request['id'];
            syncerize_wc_convert_gid_to_id($product_id);
            $product_id = syncerize_wc_decode_resource_id($product_id);

            // Add product tags
            wp_set_object_terms($product_id, $request['tags'], 'product_tag', true);

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'tagsAdd' => [
                                'userErrors' => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function is used to retrieve product option(s)
     *
     * @param $product
     *
     * @return array
     */
    private function get_product_options($product): array
    {
        $options = [];

        $attributes = $product->get_attributes();

        $i = 0;

        // Get Products
        foreach ($attributes as $key => $attribute) {
            $option_id = $product->get_id() . $i;

            $options[] = [
                'id' => syncerize_wc_generate_resource_id('option', $option_id),
                'product_id' => syncerize_wc_generate_resource_id('product', $product->get_id()),
                'name' => ucfirst($key),
                'position' => ++$i,  // @TODO: Change it to fetch from attributes
                'values' => explode(" | ", $product->get_attribute($key))
            ];
        }

        return $options;
    }

    /**
     * This function gets formatted variants for
     * create product response
     *
     * @param $product
     *
     * @return array
     */
    private function get_variants_for_create_product_response($product): array
    {
        $product = wc_get_product($product->get_id());

        $variants_data = [];

        // Check if product is variable and has variation(s) else
        // treat the variable product as any other product
        if ($product->is_type('variable') && count($product->get_children()) > 0) {
            $variations = $product->get_children();

            foreach ($variations as $key => $id) {
                $variant = new WC_Product_Variation($id);

                $variant_id = syncerize_wc_generate_resource_id('variant', $variant->get_id());

                $attributes = $variant->get_attributes();

                $variants_data[$key] = [
                    "id" => $variant_id,
                    "product_id" => syncerize_wc_generate_resource_id('product', $product->get_id()),
                    "title" => implode(" / ", $attributes),
                    "price" => $variant->get_price() ?: '0.00',
                    "position" => 1,
                    "inventory_policy" => "deny",
                    "compare_at_price" => null,
                    "created_at" => $product->get_date_created()->date('c'),
                    "updated_at" => $product->get_date_modified()->date('c'),
                    "taxable" => true,
                    "barcode" => get_post_meta($variant->get_id(), '_global_unique_id', true),
                    "fulfillment_service" => "manual",
                    "grams" => $this->convert_weight(
                        (double) $variant->get_weight(),
                        get_option('woocommerce_weight_unit'),
                        'g'
                    ),
                    "inventory_management" => "shopify",
                    "requires_shipping" => $variant->needs_shipping(),
                    "sku" => get_post_meta($variant->get_id(), '_sku', true),
                    "weight" => $variant->get_weight(),
                    "weight_unit" => get_option('woocommerce_weight_unit'),
                    'inventory_item_id' => $variant_id,
                    "inventory_quantity" => $variant->get_stock_quantity() ?? 0,
                    "old_inventory_quantity" => get_post_meta($variant->get_id(), '_old_stock_quantity', true),
                    "admin_graphql_api_id" => "gid://woocommerce/ProductVariant/$variant_id",
                    "image_id" => null
                ];

                $i = 0;

                // Add options
                foreach ($attributes as $attribute) {
                    $variants_data[$key]['option' . ++$i] = $attribute;
                }

                // Add null options
                while ($i < 3) {
                    $variants_data[$key]["option" . ++$i] = null;
                }
            }
        } else {
            $variant_id = syncerize_wc_generate_resource_id('variant', $product->get_id());

            // Add self variant
            $variants_data[] = [
                "id" => $variant_id,
                "product_id" => syncerize_wc_generate_resource_id('product', $product->get_id()),
                "title" => 'Default Title',
                "price" => $product->get_price() ?: '0.00',
                "position" => 1,
                "inventory_policy" => "deny",
                "compare_at_price" => null,
                "created_at" => $product->get_date_created()->date('c'),
                "updated_at" => $product->get_date_modified()->date('c'),
                "taxable" => true,
                "barcode" => get_post_meta($product->get_id(), '_global_unique_id', true),
                "fulfillment_service" => "manual",
                "grams" => $this->convert_weight(
                    (double) $product->get_weight(),
                    get_option('woocommerce_weight_unit'),
                    'g'
                ),
                "inventory_management" => "shopify",
                "requires_shipping" => $product->needs_shipping(),
                "sku" => get_post_meta($product->get_id(), '_sku', true),
                "weight" => $product->get_weight(),
                "weight_unit" => get_option('woocommerce_weight_unit'),
                'inventory_item_id' => $variant_id,
                "inventory_quantity" => $product->get_stock_quantity() ?? 0,
                "old_inventory_quantity" => get_post_meta($product->get_id(), '_old_stock_quantity', true),
                "admin_graphql_api_id" => "gid://woocommerce/ProductVariant/$variant_id",
                "image_id" => null,

                // Adding option values for self variant
                "option1" => 'Default Title',
                "option2" => null,
                "option3" => null
            ];
        }

        return $variants_data;
    }

    /**
     * This functionc creates product metafield
     *
     * @param $request
     * @return mixed
     */
    public function create_product_metafield($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);
            $key        = $request['data']['metafield']['key'];
            $value      = $request['data']['metafield']['value'];

            update_post_meta($product_id, $key, $value);

            // Check if metafield created
            $value        = get_post_meta($product_id, $key, true);
            $metafield_id = $this->get_metafield_id($product_id, $key);

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'metafield' => [
                            'id' => $metafield_id,
                            'namespace' => 'syncerize',
                            'key' => $key,
                            'value' => $value,
                            'description' => null,
                            'owner_id' => $request['productId'],
                            'created_at' => date('c'),
                            'updated_at' => date('c'),
                            'owner_resource' => 'product',
                            'type' => 'single_line_text_field',
                            'admin_graphql_api_id' => 'gid://woocommerce/Metafield/' . $metafield_id
                        ]
                    ]

                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function gets weight in converted unit
     *
     * @param $weight
     * @param $weight_unit
     * @param  string  $conversion_unit
     *
     * @return float|int
     */
    private function convert_weight($weight, $weight_unit, string $conversion_unit = '')
    {
        if (!empty($conversion_unit)) {
            $woocommerce_unit = $conversion_unit;
        } else {
            $woocommerce_unit = get_option('woocommerce_weight_unit');
        }

        $conversion_rates = [
            'lbs' => ['oz' => 0.0625, 'kg' => 2.20462, 'g' => 0.00220462],
            'g' => ['oz' => 28.3495, 'kg' => 1000, 'lb' => 453.592],
            'oz' => ['lb' => 16, 'kg' => 35.274, 'g' => 0.035274],
            'kg' => ['lb' => 0.453592, 'oz' => 0.0283495, 'g' => 0.001]
        ];

        foreach ($conversion_rates[$woocommerce_unit] as $unit => $value) {
            if ($unit == $weight_unit) {
                return $weight * $value;
            }
        }

        return $weight;
    }

    /**
     * This function is used to retrieve product variant metafield(s)
     *
     * @param $request
     *
     * @return mixed
     */
    public function get_product_variant_metafields($request)
    {
        try {
            $variant_id = syncerize_wc_decode_resource_id($request['variantId']);

            $custom_fields = get_post_meta($variant_id) ?? [];
            $metafields    = [];

            foreach ($custom_fields as $key => $value) {
                // To avoid internal metadata
                if (strpos($key, '_vendor_product_') !== false) {
                    $metafields[] = [
                        'node' => [
                            'key' => $key,
                            'type' => 'single_line_text_field',
                            'value' => $value[0],
                            'namespace' => 'syncerize'
                        ]
                    ];
                }
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'productVariant' => [
                                'metafields' => [
                                    'edges' => $metafields
                                ]
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    public function get_product_variants_metafields_by_product($request)
    {
        try {
            $variantIds = $request['variantIds'] ?? [];
            $namespace = 'syncerize';
            $nodes = [];

            foreach ($variantIds as $variantIdEncoded) {

                $variantId = syncerize_wc_decode_resource_id($variantIdEncoded);

                $custom_fields = get_post_meta($variantId) ?? [];
                $edges = [];

                foreach ($custom_fields as $key => $value) {

                    if (strpos($key, '_vendor_product_') !== false) {
                        $edges[] = [
                            'node' => [
                                'key'       => $key,
                                'type' => 'single_line_text_field',
                                'value'     => $value[0],
                                'namespace' => $namespace
                            ]
                        ];
                    }
                }

                // push node into nodes array
                $nodes[] = [
                    'legacyResourceId' => $variantIdEncoded,
                    'metafields'       => [
                        'edges' => $edges
                    ]
                ];
            }

            return rest_ensure_response([
                'errors'   => false,
                'response' => [],
                'status'   => 200,
                'body'     => [
                    'data' => [
                        'product' => [
                            'variants' => [
                                'nodes' => $nodes
                            ]
                        ]
                    ]
                ]
            ]);

        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }


    /**
     * This function is used to update inventory item (Set HS Code and Country Code of Origin)
     *
     *
     * @param $request
     *
     * @return mixed
     */
    public function update_inventory_item($request)
    {
        // @TODO: Need to implement it later on
        return rest_ensure_response(
            [
                'errors' => true,
                'status' => 500,
                'exception' => [
                    'message' => 'Inventory Item Update (Setting HS Code and Country Code of Origin) not working..',
                    'code' => 500
                ]
            ]
        );
        try {
            $variant_id = syncerize_wc_decode_resource_id($request['variantId']);


            $inventory_item_id = syncerize_wc_generate_unique_id();

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'inventory_item' => [
                            'id' => $inventory_item_id,
                            "sku" => "",
                            "created_at" => "2024-11-04T21:24:21+05:00",
                            "updated_at" => "2024-11-04T21:24:27+05:00",
                            "requires_shipping" => true,
                            "cost" => null,
                            "country_code_of_origin" => "CV",
                            "province_code_of_origin" => null,
                            "harmonized_system_code" => "3456346",
                            "tracked" => true,
                            "country_harmonized_system_codes" => [
                            ],
                            'admin_graphql_api_id' => 'gid://woocommerce/Metafield/' . $inventory_item_id
                        ]
                    ]

                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function sets image in product image
     * in a specific position
     *
     * @param $product
     * @param $position
     * @param $image_id
     */
    private function set_image_in_product_gallery($product, $position, $image_id)
    {
        $gallery_ids = $product->get_gallery_image_ids();

        // Ensure the position does not exceed the current array length
        $position = min($position, count($gallery_ids));

        // Insert the new image at the specified position, shifting others forward
        array_splice($gallery_ids, $position, 0, $image_id);

        $product->set_gallery_image_ids($gallery_ids);
        $product->save();
    }

    /**
     * This function deletes a product
     *
     * @param $request
     *
     * @return mixed
     */
    public function delete_product($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);

            $product = wc_get_product($product_id);

            if ($product) {
                if ($product->is_type('variable')) {
                    // Delete all children
                    foreach ($product->get_children() as $variant_id) {
                        $variant = wc_get_product($variant_id);
                        $variant->delete(true);
                    }
                }

                // true is for permanent delete
                $product->delete(true);
            }

            $deletedProductId = $product ? $request['productId'] : null;

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'productDelete' => [
                                'deletedProductId' => $deletedProductId,
                                'userErrors' => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function is used to set key if reserved
     * namespace found
     *
     * @param $namespace
     * @param $key
     */
    private function set_reserved_namespace_key($namespace, &$key)
    {
        if (strpos($namespace, '--syncerize') !== false &&
            strpos($key, '_') !== 0) {
            $key = "_$key";
        }
    }

    /**
     * This function is used to set metafield
     *
     * @param $metafield
     *
     * @return array
     */
    private function set_metafield($metafield): array
    {
        [, , , $owner_type, $owner_id] = explode('/', $metafield['ownerId']);
        $owner_id = syncerize_wc_decode_resource_id($owner_id);

        $key = $metafield['key'];

        if ($owner_type == 'ProductVariant' || $owner_type == 'Product') {
            $this->set_reserved_namespace_key($metafield['namespace'], $key);

            update_post_meta($owner_id, $key, $metafield['value']);
        }

        // Owner type response values
        $owner_types = [
            'Product' => 'PRODUCT',
            'ProductVariant' => 'PRODUCTVARIANT',
        ];

        $metafield_id = $this->get_metafield_id($owner_id, $key);

        return [
            'id' => "gid://woocommerce/Metafield/" . $metafield_id,
            'key' => $key,
            'namespace' => $metafield['namespace'],
            'value' => get_post_meta($owner_id, $key, true) ?: 'no_value_set',
            'description' => null,
            'type' => $metafield['type'],
            'ownerType' => $owner_types[$owner_type],
            'legacyResourceId' => $metafield_id,
            'createdAt' => date('c'),
            'updatedAt' => date('c')
        ];
    }

    /**
     * This function is used to return set
     * metafields response
     *
     * @param $body
     *
     * @return mixed
     */
    private function set_metafields_response($body)
    {
        return rest_ensure_response(
            [
                'errors' => false,
                'response' => [],
                'status' => 200,
                'body' => [
                    'data' => [
                        'metafieldsSet' => [
                            'metafields' => $body,
                            'userErrors' => []
                        ]
                    ]
                ]
            ]
        );
    }

    /**
     * This function is used to set metafield(s)
     *
     * @param $request
     *
     * @return mixed
     */
    public function set_metafields($request)
    {
        try {
            // If metafield is not in bulk
            if (!$request['inBulk']) {
                return $this->set_metafields_response(
                    [
                        $this->set_metafield($request['metafields'])
                    ]
                );
            } else {
                $body = [];

                foreach ($request['metafields'] as $metafield) {
                    $body[] = $this->set_metafield($metafield);
                }

                return $this->set_metafields_response(['container' => $body]);
            }
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function searches variant(s) via product id
     *
     * @param $request
     *
     * @return mixed
     */
    public function search_variants_by_product_id($request)
    {
        try {
            $product_id  = syncerize_wc_decode_resource_id($request['productId']);
            $product     = wc_get_product($product_id);
            $productBody = null;

            // If a parent product exists
            if ($product && $product->get_type() !== 'variation') {
                $variation_ids = $product->get_children();
                $variants      = [];

                foreach ($variation_ids as $variation_id) {
                    $variant = wc_get_product($variation_id);

                    $variants[] = [
                        'id' => syncerize_wc_generate_resource_id('variant', $variant->get_id()),
                        'sku' => get_post_meta($variation_id, '_sku', true),
                        'barcode' => get_post_meta($variant->get_id(), '_global_unique_id', true)
                    ];
                }

                // Add self variant if no variant found
                if (empty($variants)) {
                    $variants[] = [
                        'id' => syncerize_wc_generate_resource_id('variant', $product_id),
                        'sku' => get_post_meta($product_id, '_sku', true),
                        'barcode' => get_post_meta($product_id, '_global_unique_id', true)
                    ];
                }

                $productBody = ['variants' => ['nodes' => $variants]];
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'id' => $product_id,
                            'title' => $product->get_title(),
                            'product' => $productBody
                        ]
                    ],
                    'type' => $product->get_type()
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function returns empty search product
     * response body
     *
     * @param $identifier
     *
     * @return mixed
     */
    private function empty_search_products_response($identifier)
    {
        return rest_ensure_response(
            [
                'errors' => false,
                'response' => [],
                'status' => 200,
                'body' => [
                    'data' => [
                        'products' => [
                            'edges' => []
                        ]
                    ]
                ],
                'identifier' => $identifier
            ]
        );
    }

    /**
     * This function returns variant node
     * for search products call
     *
     * @param $product_id
     * @return array[]
     */
    private function get_search_products_variant_node($product_id): array
    {
        $product = wc_get_product($product_id);

        return [
            'node' => [
                'id' => 'gid://woocommerce/ProductVariant/' . syncerize_wc_generate_resource_id(
                        'variant',
                        $product->get_id()
                    ),
                'sku' => $product->get_sku(),
                'barcode' => get_post_meta($product->get_id(), '_global_unique_id', true)
            ]
        ];
    }

    public function check_codes_exist($codes, $unique_identifier)
    {
        foreach ($codes as $code) {
            if ($unique_identifier == 'sku') {
                $product_id = wc_get_product_id_by_sku($code);
            } else {
                $product_id = syncerize_wc_get_product_id_by_barcode($code);
            }

            // if product exists
            if ($product_id) {
                $product     = wc_get_product($product_id);
                $variant_ids = $product->get_children();
                $variants    = [];

                if ($product->get_type() == 'variable' && $variant_ids) {
                    foreach ($variant_ids as $variant_id) {
                        $variants[] = $this->get_search_products_variant_node($variant_id);
                    }
                } else {
                    $variants[] = $this->get_search_products_variant_node($product_id);
                }

                return rest_ensure_response(
                    [
                        'errors' => false,
                        'response' => [],
                        'status' => 200,
                        'body' => [
                            'data' => [
                                'products' => [
                                    'edges' => [
                                        [
                                            'node' => [
                                                'id' => "gid://woocommerce/Product/" . syncerize_wc_generate_resource_id(
                                                        'product',
                                                        $product_id
                                                    ),
                                                'variants' => [
                                                    'edges' => $variants
                                                ]
                                            ]
                                        ]
                                    ]
                                ]
                            ]
                        ],
                        'identifier' => $unique_identifier
                    ]
                );
            }
        }

        return false;
    }

    /**
     * This function get a simple or variable product with
     * no variation
     *
     * @param $unique_codes
     * @param $unique_identifier
     *
     * @return mixed
     */
    private function get_product_with_no_variations($unique_codes, $unique_identifier)
    {
        if (count($unique_codes) == 1) {
            // create function name
            $get_product_id = $this->get_product_id_by_unique_identifier_function_name($unique_identifier);

            // Get product id by unique identifier
            $product_id = $get_product_id($unique_codes[0]);

            $product = wc_get_product($product_id);

            // check simple/variable product with no variations
            if ($product && count($product->get_children()) == 0 && !$product->is_type('variation')) {
                return $product;
            }
        }

        return false;
    }

    /**
     * This function is used to check if product type is compatible
     * for displaying in map preview
     *
     * @param $product_type
     * @param $product
     *
     * @return bool
     */
    private function supports_mapping($product_type, $product): bool
    {
        // For map preview check product type
        if ($product_type != 'shopify-product' &&
            $product_type != $product->get_type()) {
            return false;
        }

        return true;
    }

    /**
     * This function retrieves product(s) based on query
     *
     * @param $request
     *
     * @return mixed
     */
    public function search_products($request)
    {
        try {
            $unique_identifiers = $this->get_unique_identifier_data($request['searchQuery']);

            $unique_identifier = $unique_identifiers['type'];

            $unique_codes = $unique_identifiers['values'];

            $parent_product_id = 0;
            $variants          = ['edges' => []];

            // In case of sync
            if ($request['flag'] == 'sync') {
                error_log('secondaryCodes: '.gettype($request['secondaryCodes']));
                error_log('secondaryCodes(is_null): '.(is_null($request['secondaryCodes']) ? 'true' : 'false'));

                // Check secondary unique identifier
                $secondaryCodeResponse = $this->check_codes_exist(
                    $request['secondaryCodes'],
                    $request['secondaryUniqueId']
                );

                if ($secondaryCodeResponse) {
                    return $secondaryCodeResponse;
                }

                // Check unique identifier found
                $primaryCodeResponse = $this->check_codes_exist($unique_codes, $unique_identifier);

                if ($primaryCodeResponse) {
                    return $primaryCodeResponse;
                }
            }

            $product = $this->get_product_with_no_variations($unique_codes, $unique_identifier);

            // handle simple/variable with no variation product
            if ($product) {
                $featuredImage = $this->get_featured_image_src($product);

                // For map preview check product type
                if ($request['flag'] == 'map-preview' && !$this->supports_mapping($request['productType'], $product)) {
                    return $this->empty_search_products_response($unique_identifier);
                }

                return rest_ensure_response(
                    [
                        'errors' => false,
                        'response' => [],
                        'status' => 200,
                        'body' => [
                            'data' => [
                                'products' => [
                                    'edges' => [
                                        [
                                            'node' => [
                                                'id' => "gid://woocommerce/Product/" . syncerize_wc_generate_resource_id(
                                                        'product',
                                                        $product->get_id()
                                                    ),
                                                'title' => $product->get_title(),
                                                'status' => ($product->get_status() == 'publish') ? 'ACTIVE' : 'DRAFT',
                                                'featuredImage' => isset($featuredImage) ? ['thumbnail' => $featuredImage] : null,
                                                'variants' => [
                                                    'edges' => [
                                                        [
                                                            'node' => [
                                                                'id' => 'gid://woocommerce/ProductVariant/' . syncerize_wc_generate_resource_id(
                                                                        'variant',
                                                                        $product->get_id()
                                                                    ),
                                                                'sku' => $product->get_sku(),
                                                                'barcode' => get_post_meta(
                                                                    $product->get_id(),
                                                                    '_global_unique_id',
                                                                    true
                                                                )
                                                            ]
                                                        ]
                                                    ]
                                                ]
                                            ]
                                        ]
                                    ]
                                ]
                            ]
                        ],
                        'identifier' => $unique_identifier,
                        'type' => $product->get_type()
                    ]
                );
            }

            // handling variable product with variation(s)
            foreach ($unique_codes as $unique_code) {
                // create function name
                $get_product_id = $this->get_product_id_by_unique_identifier_function_name($unique_identifier);

                // Get product id by unique identifier
                $product_id = $get_product_id($unique_code);

                if ($product_id) {
                    $product = wc_get_product($product_id);

                    // If product is a variable
                    if ($product->is_type('variable')) {
                        // empty response if product type is variable
                        return $this->empty_search_products_response($unique_identifier);
                    }

                    if ($product->is_type('variation')) {
                        $variation_parent_id = $product->get_parent_id();

                        // if parent product isn't found yet
                        if ($parent_product_id == 0) {
                            $parent_product_id = $variation_parent_id;
                        }

                        // if sku exists in a different parent product
                        if ($variation_parent_id != $parent_product_id) {
                            return $this->empty_search_products_response($unique_identifier);
                        }

                        // Append variant
                        $variants['edges'][] = [
                            'node' => [
                                'id' => 'gid://woocommerce/ProductVariant/' . syncerize_wc_generate_resource_id(
                                        'variant',
                                        $product->get_id()
                                    ),
                                'sku' => $product->get_sku(),
                                'barcode' => get_post_meta(
                                    $product->get_id(),
                                    '_global_unique_id',
                                    true
                                )
                            ]
                        ];
                    } else {
                        // empty result if type is not variation
                        return $this->empty_search_products_response($unique_identifier);
                    }
                } else {
                    return $this->empty_search_products_response($unique_identifier);
                }
            }

            if ($parent_product_id == 0) {
                return $this->empty_search_products_response($unique_identifier);
            }

            $parent_product = wc_get_product($parent_product_id);


            // For map preview check product type
            if ($request['flag'] == 'map-preview' && !$this->supports_mapping(
                    $request['productType'],
                    $parent_product
                )) {
                return $this->empty_search_products_response($unique_identifier);
            }

            $featuredImage = $this->get_featured_image_src($parent_product);

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'products' => [
                                'edges' => [
                                    [
                                        'node' => [
                                            'id' => "gid://woocommerce/Product/" . syncerize_wc_generate_resource_id(
                                                    'product',
                                                    $parent_product_id
                                                ),
                                            'title' => $parent_product->get_title(),
                                            'featuredImage' => isset($featuredImage) ? ['originalSrc' => $featuredImage] : null,
                                            'status' => ($parent_product->get_status(
                                                ) == 'publish') ? 'ACTIVE' : 'DRAFT',
                                            'variants' => $variants
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ],
                    'identifier' => $unique_identifier,
                    'type' => $parent_product->get_type()
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function fetches product legacy resource id
     * based on unique identifier(s)
     *
     * @param $request
     *
     * @return mixed
     */
    public function fetch_product_legacy_resource_id($request)
    {
        try {
            $unique_identifiers = $this->get_unique_identifier_data($request['query']);

            $unique_identifier = $unique_identifiers['type'];

            $unique_codes = $unique_identifiers['values'];

            $product = $this->get_product_with_no_variations($unique_codes, $unique_identifier);

            // handle simple/variable with no variation product
            if ($product) {
                // Check product types support mapping
                if (!$this->supports_mapping($request['productType'], $product)) {
                    return $this->empty_search_products_response($unique_identifier);
                }

                return rest_ensure_response(
                    [
                        'errors' => false,
                        'response' => [],
                        'status' => 200,
                        'body' => [
                            'data' => [
                                'products' => [
                                    'edges' => [
                                        [
                                            'node' => [
                                                'legacyResourceId' => syncerize_wc_generate_resource_id(
                                                    'product',
                                                    $product->get_id()
                                                )
                                            ]
                                        ]
                                    ]
                                ]
                            ]
                        ],
                        'type' => $product->get_type()
                    ]
                );
            }

            $parent_product_id = 0;

            // handling variable product with variation(s)
            foreach ($unique_codes as $unique_code) {
                // create function name
                $get_product_id = $this->get_product_id_by_unique_identifier_function_name($unique_identifier);

                // Get product id by unique identifier
                $product_id = $get_product_id($unique_code);

                if ($product_id) {
                    $product = wc_get_product($product_id);

                    // If product is a variable
                    if ($product->is_type('variable')) {
                        // empty response if product type is variable
                        return $this->empty_search_products_response($unique_identifier);
                    }

                    if ($product->is_type('variation')) {
                        $variation_parent_id = $product->get_parent_id();

                        // if parent product isn't found yet
                        if ($parent_product_id == 0) {
                            $parent_product_id = $variation_parent_id;
                        }

                        // if sku exists in a different parent product
                        if ($variation_parent_id != $parent_product_id) {
                            return $this->empty_search_products_response($unique_identifier);
                        }
                    } else {
                        // empty result if type is not variation
                        return $this->empty_search_products_response($unique_identifier);
                    }
                } else {
                    return $this->empty_search_products_response($unique_identifier);
                }
            }

            if ($parent_product_id == 0) {
                return $this->empty_search_products_response($unique_identifier);
            }

            $parent_product = wc_get_product($parent_product_id);

            // Check product types support mapping
            if (!$this->supports_mapping($request['productType'], $parent_product)) {
                return $this->empty_search_products_response($unique_identifier);
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'products' => [
                                'edges' => [
                                    [
                                        'node' => [
                                            'legacyResourceId' => syncerize_wc_generate_resource_id(
                                                'product',
                                                $parent_product_id
                                            )
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ],
                    'type' => $parent_product->get_type()
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function is used to retrieve unique identifier
     * and it's value(s) from given string
     *
     * @param $query
     *
     * @return array
     */
    private function get_unique_identifier_data($query): array
    {
        $unique_identifiers = ["sku", "barcode"];

        foreach ($unique_identifiers as $unique_identifier) {
            if (strpos($query, "$unique_identifier:") === 0) {
                preg_match_all("/$unique_identifier:\s*'([^']+)'/", $query, $matches);

                return [
                    'type' => $unique_identifier,
                    'values' => $matches[1]
                ];
            }
        }

        // Default fallback to keep static analyzer happy and avoid fatal errors upstream
        // Will result in an empty search response in fetch_product_legacy_resource_id
        return [
            'type' => 'sku',
            'values' => []
        ];
    }

    /**
     * This function retrieves a dummy first
     * location
     *
     *
     * @param $request
     *
     * @return mixed
     */
    public function fetch_location_info($request)
    {
        try {
            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'locations' => [
                                'edges' => [
                                    [
                                        'node' => [
                                            'id' => "gid://woocommerce/Location/" . syncerize_wc_generate_unique_id(),
                                            'legacyResourceId' => syncerize_wc_generate_unique_id(),
                                            'name' => '',
                                            'address' => [
                                                'address1' => '',
                                                'city' => '',
                                                'country' => ''
                                            ]
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    public function get_inventory_level($request)
    {
        try {
            $variant_id = syncerize_wc_decode_resource_id($request['inventoryItemId']);
            $product = wc_get_product($variant_id);
            $stock = $product->get_stock_quantity();

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'inventoryItem' => [
                                'inventoryLevel' => [
                                    'quantities' => [
                                        [
                                            'name' => 'available',
                                            'quantity' => $stock,
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    public function fetch_default_location($request)
    {
        try {
            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'location' => [
                                'id' => 'gid://woocommerce/Location/' . syncerize_wc_generate_unique_id(),
                                'legacyResourceId' => syncerize_wc_generate_unique_id(),
                                'name' => '',
                                'address' => [
                                    'address1' => '',
                                    'city' => '',
                                    'country' => ''
                                ]
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    public function fetch_product_variants_quantity($request)
    {
        try {
            error_log('Product ID: ' . json_encode($request['productId']));
            $productId = syncerize_wc_decode_resource_id($request['productId']);
            $product = wc_get_product($productId);

            if (! $product) {
                return rest_ensure_response(
                    [
                        'errors' => true,
                        'response' => [],
                        'status' => 404,
                        'exception' => [
                            'message' => 'Product not found.'
                        ]
                    ]
                );
            }

            $nodes = [];

            // Variable product (multiple variants)
            if ($product->is_type('variable')) {
                foreach ($product->get_children() as $variationId) {
                    $variation = wc_get_product($variationId);

                    if (! $variation) {
                        continue;
                    }

                    $nodes[] = [
                        'legacyResourceId' => syncerize_wc_generate_resource_id('variant', $variationId),
                        'inventoryItem' => [
                            'inventoryLevel' => [
                                'quantities' => [
                                    [
                                        'quantity' => (int) ($variation->get_stock_quantity() ?? 0),
                                    ]
                                ]
                            ]
                        ]
                    ];
                }
            }
            // Simple product (single variant)
            else {
                $nodes[] = [
                    'legacyResourceId' => syncerize_wc_generate_resource_id('variant', $product->get_id()),
                    'inventoryItem' => [
                        'inventoryLevel' => [
                            'quantities' => [
                                [
                                    'quantity' => (int) ($product->get_stock_quantity() ?? 0),
                                ]
                            ]
                        ]
                    ]
                ];
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'product' => [
                                'variants' => [
                                    'nodes' => $nodes
                                ]
                            ]
                        ]
                    ]
                ]
            );

        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function returns response
     * for inventory activate
     *
     * @param $request
     *
     * @return mixed
     */
    public function inventory_activate($request)
    {
        try {
            return rest_ensure_response(
                [
                    "errors" => false,
                    "response" => [],
                    "status" => 200,
                    "body" => [
                        "data" => [
                            "inventoryActivate" => [
                                "userErrors" => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function returns response
     * for inventory activate
     *
     * @param $request
     *
     * @return mixed
     */
    public function inventory_set_quantities($request)
    {
        try {
            $variant_id = syncerize_wc_decode_resource_id($request['data']['variant_id']);

            // Load the product
            $product = wc_get_product($variant_id);

            // Manage stock
            $product->set_manage_stock(true);

            // Update the stock quantity
            $product->set_stock_quantity($request['data']['available']);

            // Save the product
            $product->save();

            return rest_ensure_response(
                [
                    "errors" => false,
                    "response" => [],
                    "status" => 200,
                    "body" => [
                        "data" => [
                            "inventorySetQuantities" => [
                                "userErrors" => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function updates a product metafield
     *
     * @param $request
     *
     * @return mixed
     */
    public function update_product_metafield($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);
            $key        = $request['data']['key'];

            // Update/Add Post Metafield
            update_post_meta($product_id, $key, $request['data']['value']);

            $metafield_id = $this->get_metafield_id($product_id, $key);

            return rest_ensure_response(
                [
                    "errors" => false,
                    "response" => [],
                    "status" => 200,
                    "body" => [
                        "metafield" => [
                            'id' => $metafield_id,
                            'namespace' => 'syncerize',
                            'key' => $key,
                            'value' => get_post_meta($product_id, $key, true),
                            'description' => null,
                            'owner_id' => $request['productId'],
                            'created_at' => date('c'),
                            'updated_at' => date('c'),
                            'owner_resource' => 'product',
                            'type' => 'single_line_text_field',
                            'admin_graphql_api_id' => 'gid://woocommerce/Metafield/' . $metafield_id
                        ]
                    ],
                    "link" => null,
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function deletes a product
     * metafield
     *
     * @param $request
     *
     * @return mixed
     */
    public function delete_metafields($request)
    {
        try {
            foreach ($request['metafield'] as $metafield) {
                $owner_id = $metafield['ownerId'];
                syncerize_wc_convert_gid_to_id($owner_id);

                $product_id    = syncerize_wc_decode_resource_id($owner_id);
                $metafield_key = $metafield['key'];

                delete_post_meta($product_id, $metafield_key);
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'metafieldsDelete' => [
                                'deletedMetafields' => [
                                    'key' => $request['metafield'][0]['key'],
                                    'namespace' => $request['metafield'][0]['namespace'],
                                    'ownerId' => $request['metafield'][0]['ownerId']
                                ],
                                'userErrors' => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function retrieves product variant(s) metafield
     *
     * @param $request
     *
     * @return mixed
     */
    public function get_product_variant_metafield_by_key($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);

            $product = wc_get_product($product_id);

            $product_body = [
                'edges' => []
            ];

            // Product exists and is of type variable with variation(s)
            if ($product && $product->get_children()) {
                $variant_ids = $product->get_children();

                $variants = ['edges' => []];

                foreach ($variant_ids as $variant_id) {
                    $id = syncerize_wc_generate_resource_id('variant', $variant_id);

                    $metafield = get_post_meta($variant_id, $request['key'], true);

                    if ($metafield) {
                        $metafield = [
                            'node' => [
                                'key' => $request['key'],
                                'value' => $metafield
                            ]
                        ];
                    }

                    $variants['edges'][] = [
                        'node' => [
                            'id' => "gid://woocommerce/ProductVariant/$id",
                            'metafields' => [
                                'edges' => $metafield ? [$metafield] : []
                            ]
                        ]
                    ];
                }

                // Add variants to body
                $product_body['edges'] = [
                    [
                        'node' => [
                            'variants' => $variants
                        ]
                    ]
                ];
            } elseif ($product) {
                // in case of simple/variable product with no variations
                $id = syncerize_wc_generate_resource_id('variant', $product->get_id());

                $metafield = get_post_meta($product->get_id(), $request['key'], true);

                if ($metafield) {
                    $metafield = [
                        'node' => [
                            'key' => $request['key'],
                            'value' => $metafield
                        ]
                    ];
                }

                $variants['edges'][] = [
                    'node' => [
                        'id' => "gid://woocommerce/ProductVariant/$id",
                        'metafields' => [
                            'edges' => $metafield ? [$metafield] : []
                        ]
                    ]
                ];

                // Add variants to body
                $product_body['edges'] = [
                    [
                        'node' => [
                            'variants' => $variants
                        ]
                    ]
                ];
            }

            return rest_ensure_response(
                [
                    "errors" => false,
                    "response" => [],
                    "status" => 200,
                    "body" => [
                        'data' => [
                            'products' => $product_body
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function is used to fetch product image(s)
     *
     * @param $request
     *
     * @return mixed
     */
    public function fetch_product_images($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);
            $product    = wc_get_product($product_id);

            $image_ids = $this->get_product_image_ids($product);

            $response = [
                'errors' => false,
                'response' => [],
                'status' => 200,
                'body' => [
                    'data' => [
                        'product' => [
                            'media' => [
                                'nodes' => [],
                                'pageInfo' => [
                                    'startCursor' => null,
                                    'endCursor' => null
                                ]
                            ]
                        ]
                    ]
                ]
            ];

            // Adding custom media image ids
            foreach ($image_ids as $key => $image_id) {
                $media_id = syncerize_wc_generate_resource_id('media', $image_id);

                $response['body']['data']['product']['media']['nodes'][] = [
                    'id' => "gid://woocommerce/MediaImage/$media_id",
                ];

                if ($key === 9) {
                    break;
                }
            }

            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * Retrieves product image metafield(s)
     *
     * @param $request
     *
     * @return mixed
     */
    public function get_product_image_metafields($request)
    {
        try {
            $product_id = syncerize_wc_decode_resource_id($request['productId']);
            $product    = wc_get_product($product_id);

            $product_body = [
                "edges" => []
            ];

            if ($product) {
                $image = [];
                $media = [];

                $image_ids = $this->get_product_image_ids($product);

                foreach ($image_ids as $index => $image_id) {
                    // Append image record
                    $image[$index] = [
                        'node' => [
                            'id' => "gid://woocommerce/ProductImage/" . syncerize_wc_generate_resource_id(
                                    'image',
                                    $image_id
                                ),
                            'url' => $this->get_image_src($image_id)
                        ]
                    ];

                    // Append media record
                    $media[$index] = [
                        'node' => [
                            'id' => "gid://woocommerce/MediaImage/" . syncerize_wc_generate_resource_id(
                                    'media',
                                    $image_id
                                ),
                            'mediaContentType' => 'IMAGE',
                            'metafields' => [
                                'nodes' => []
                            ],
                            'image' => [
                                'url' => $this->get_image_src($image_id)
                            ]
                        ]
                    ];

                    // Retrieve all metadata for the product
                    $image_metafields = get_post_meta($image_id);

                    // Append metafield(s)
                    foreach ($image_metafields as $key => $value) {
                        $media[$index]['node']['metafields']['nodes'][] = [
                            'key' => $key,
                            'value' => $value[0]
                        ];
                    }
                }

                $product_body["edges"] = [
                    [
                        "node" => [
                            "images" => [
                                "edges" => [
                                    'container' => $image
                                ]
                            ],
                            "media" => [
                                "edges" => [
                                    'container' => $media
                                ]
                            ]
                        ]
                    ]
                ];
            }

            return rest_ensure_response(
                [
                    "errors" => false,
                    "response" => [],
                    "status" => 200,
                    'body' => [
                        "data" => [
                            "products" => $product_body
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function deletes old variation(s) from
     * product
     *
     * @param $product
     * @param $variant_ids
     */
    private function delete_old_variations($product, $variant_ids)
    {
        // Delete old variant(s)
        $all_variants = $product->get_children();

        foreach ($all_variants as $variant_id) {
            if (!in_array($variant_id, $variant_ids)) {
                $variant = wc_get_product($variant_id);

                $variant->delete(true);
            }
        }
    }

    /**
     * This function checks if the barcode is
     * compatible for update
     *
     * @param $barcode
     *
     * @return bool
     */
    private function is_barcode_compatible_for_update($barcode): bool
    {
        // if barcode not already set and is it's format compatible
        if (!syncerize_wc_get_product_id_by_barcode($barcode) &&
            syncerize_wc_is_barcode_format_compatible($barcode)) {
            return true;
        }

        return false;
    }

    /**
     * This function used to update a product
     *
     * @param $request
     *
     * @return mixed
     */
    public function update_product($request)
    {
        try {
            $request['product']     = $request['bulkProdData']['prod']['product'];
            $client_product_setting = $request['bulkProdData']['customData']['clientProductSetting'];

            $product_id = syncerize_wc_decode_resource_id($request['productId']);

            $product = wc_get_product($product_id);

            if (!$product) {
                throw new Exception('Product not found.');
            }

            $variant_count = isset($request['product']['variants']) ? count($request['product']['variants']) : 0;

            // Update product title, description, and status
            if (isset($request['product']['title'])) {
                $product->set_name($request['product']['title']);
            }

            if (isset($request['product']['body_html'])) {
                $product->set_description($request['product']['body_html']);
            }

            if (isset($request['product']['status'])) {
                // For woo to woo pending status is set to draft
                $product->set_status($request['product']['status'] === 'active' ? 'publish' : 'draft');
            }

            // Update tags
            if (isset($request['product']['tags'])) {
                $tags = explode(',', $request['product']['tags']);
                wp_set_object_terms($product_id, $tags, 'product_tag');
            }

            // Update attributes
            if (isset($request['product']['options'])) {
                $attributes = [];

                foreach ($request['product']['options'] as $option) {
                    $attribute = new WC_Product_Attribute();
                    $attribute->set_name(sanitize_title($option['name']));
                    $attribute->set_options($option['values']);

                    $attribute->set_visible(true);
                    $attribute->set_variation(true);
                    $attributes[] = $attribute;
                }

                $product->set_attributes($attributes);
            }

            // Save the product to apply attribute changes
            $product->save();

            $variant_ids = [];

            // Add new variations
            if ($client_product_setting['variant']) {
                if (
                    $variant_count > 1 && $product->is_type('variable')
                    || $variant_count == 1 && $product->is_type('variable')
                    || $variant_count > 1 && $product->is_type('simple')
                ) {
                    // Update/Reset product type to variable
                    $product = new WC_Product_Variable($product->get_id());

                    $product->set_regular_price('');
                    $product->set_sale_price('');
                    $product->set_sku('');

                    // Remove '_global_unique_id' metadata
                    update_post_meta($product->get_id(), '_global_unique_id', '');

                    // Update the product type in the database
                    wp_set_object_terms($product->get_id(), 'variable', 'product_type');

                    // Save the updated product
                    $product->save();

                    foreach ($request['product']['variants'] as $variant) {
                        if (isset($variant['id'])) {
                            $variant_id = syncerize_wc_decode_resource_id($variant['id']);


                            $variant_ids[] = $variant_id;
                            $variation     = wc_get_product($variant_id);

                            // If the variant isn't a variation
                            if ($variation->is_type('variable')) {
                                $variation = new WC_Product_Variation();
                                $variation->set_parent_id($product_id);
                            }
                        } else {
                            $variation = new WC_Product_Variation();
                            $variation->set_parent_id($product_id);
                        }

                        if (isset($variant['price'])) {
                            $variation->set_regular_price($variant['price'] ?: '0.00');
                            $variation->set_sale_price('');
                        }

                        // If sku exists and not already set
                        if (isset($variant['sku']) && !wc_get_product_id_by_sku($variant['sku'])) {
                            $variation->set_sku($variant['sku']);
                        }

                        // If barcode exists
                        if (isset($variant['barcode'])) {
                            if ($this->is_barcode_compatible_for_update($variant['barcode'])) {
                                $variation->update_meta_data('_global_unique_id', $variant['barcode']);
                            }
                        }

                        // Update variant option(s) if any found
                        if (isset($variant['option1'])) {
                            $options = $request['product']['options'] ?? [];

                            // Reset variant options/attributes
                            $attributes = [];
                            foreach ($options as $key => $option) {
                                $option_key = "option" . ($key + 1);

                                if (in_array($variant[$option_key], $option['values'])) {
                                    $attribute_slug              = sanitize_title($option['name']);
                                    $attributes[$attribute_slug] = $variant[$option_key];
                                }
                            }

                            $variation->set_attributes($attributes);
                        }

                        // Save the variation
                        $variation->save();

                        if (!empty($variant['metafields'])) {
                            // Set Metafields
                            foreach ($variant['metafields'] as $metafield) {
                                $this->set_reserved_namespace_key($metafield['namespace'], $metafield['key']);

                                update_post_meta($variation->get_id(), $metafield['key'], $metafield['value']);
                            }
                        }
                    }
                } else {
                    // Set fields for simple/variable with no variation product
                    // From self variant
                    $selfVariant = $request['product']['variants'][0];

                    if (isset($selfVariant['price'])) {
                        $product->set_regular_price($selfVariant['price'] ?: '0.00');
                        $product->set_sale_price('');
                    }

                    // If sku exists and not already set
                    if (isset($selfVariant['sku']) && !wc_get_product_id_by_sku($selfVariant['sku'])) {
                        $product->set_sku($selfVariant['sku']);
                    }

                    // If barcode exists
                    if (isset($selfVariant['barcode'])) {
                        if ($this->is_barcode_compatible_for_update($selfVariant['barcode'])) {
                            $product->update_meta_data('_global_unique_id', $selfVariant['barcode']);
                        }
                    }

                    $product->save();

                    if (!empty($selfVariant['metafields'])) {
                        // Set Metafields
                        foreach ($selfVariant['metafields'] as $metafield) {
                            $this->set_reserved_namespace_key($metafield['namespace'], $metafield['key']);

                            update_post_meta($product->get_id(), $metafield['key'], $metafield['value']);
                        }
                    }
                }

                // Delete old variant(s)
                $this->delete_old_variations($product, $variant_ids);
            }

            if (isset($request['product']['media'])) {
                $all_product_image_ids = $this->get_product_image_ids($product);

                $media_ids = array_column($request['product']['media'], 'id');

                // Convert gid to id for all media ids
                array_walk($media_ids, 'syncerize_wc_convert_gid_to_id');

                // Convert media ids to image ids
                $image_ids = array_map('syncerize_wc_decode_resource_id', $media_ids);

                foreach ($all_product_image_ids as $image_id) {
                    if (!in_array($image_id, $image_ids)) {
                        wp_delete_attachment($image_id, true);
                    }
                }
            }

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'product' => [
                            'id' => $request['productId'],
                            'title' => $product->get_title(),
                            'body_html' => $product->get_description(),
                            'vendor' => $request['product']['vendor'] ?? '',
                            'product_type' => $request['product']['product_type'] ?? '',
                            'created_at' => $product->get_date_created()->date('c'),
                            'handle' => '',
                            'updated_at' => $product->get_date_created()->date('c'),
                            'published_at' => $product->get_date_created()->date('c'),
                            'template_suffix' => null,
                            'published_scope' => 'web',
                            'admin_graphql_api_id' => "gid://woocommerce/Product/{$request['productId']}",
                            'tags' => implode(
                                ',',
                                wp_get_post_terms($product->get_id(), 'product_tag', ['fields' => 'names'])
                            ),
                            'status' => 'active',
                            'variants' => $this->get_variants_for_create_product_response($product),
                            'options' => $this->get_product_options($product),
                            'images' => $this->get_update_product_response_images($product),
                            'image' => $this->get_update_product_response_images(
                                $product,
                                [$product->get_image()]
                            ) ?: null
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function sets metafield definition
     *
     * @param $request
     *
     * @return mixed
     */
    public function set_metafield_definition($request)
    {
        try {
            // Sending a dummy response as metafield definition do not exist in woocommerce
            return rest_ensure_response(
                [
                    "errors" => false,
                    "response" => [],
                    "status" => 200,
                    'body' => [
                        "data" => [
                            "metafieldDefinitionCreate" => [
                                'createdDefinition' => [
                                    'id' => 'gid://woocommerce/MetafieldDefinition/' . syncerize_wc_generate_unique_id(
                                        ),
                                    'name' => $request['definition']['name']
                                ]
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function retrieves product image
     * id(s)
     *
     * @param $product
     *
     * @return array
     */
    private function get_product_image_ids($product): array
    {
        $image_ids = [];

        if ($product->get_image_id()) {
            $image_ids[] = $product->get_image_id();
        }

        $variantIds = $product->get_children();

        foreach ($variantIds as $variantId) {
            $variant = new WC_Product_Variation($variantId);

            if ($variant->get_image_id()) {
                $image_ids[] = $variant->get_image_id();
            }
        }

        if ($product->get_gallery_image_ids()) {
            array_push($image_ids, ...$product->get_gallery_image_ids());
        }

        // Remove repeated ids
        $image_ids = array_unique($image_ids);

        // Make indexing proper again
        return array_values($image_ids);
    }

    /**
     * This function retrives product images to display
     * on update product response
     *
     * @param $product
     * @param  array  $image_ids
     *
     * @return array
     */
    private function get_update_product_response_images($product, array $image_ids = []): array
    {
        if (empty($image_ids)) {
            $image_ids = $this->get_product_image_ids($product);
        }

        $images = [];

        foreach ($image_ids as $key => $image_id) {
            $image = $this->get_product_image_metadata($image_id);

            $generated_image_id = syncerize_wc_generate_resource_id('image', $image_id);

            $images[] = [
                'id' => $generated_image_id,
                'alt' => $image['altText'] ?? "",
                'position' => $key,
                'product_id' => syncerize_wc_generate_resource_id('product', $product->get_id()),
                'created_at' => get_post_time('c', true, $image_id),
                'updated_at' => get_post_modified_time('c', true, $image_id),
                'admin_graphql_api_id' => "gid://woocommerce/ProductImage/" . $generated_image_id,
                'width' => $image['width'] ?? "",
                'height' => $image['height'] ?? "",
                'src' => $image['url'] ?? "",
                'variant_ids' => $this->get_variant_ids_linked_to_image($product, $image_id)
            ];
        }

        return $images;
    }

    /**
     * The function retrieves ids of variant(s)
     * that use a specific image
     *
     * @param $product
     * @param $image_id
     *
     * @return array
     */
    private function get_variant_ids_linked_to_image($product, $image_id): array
    {
        $linked_variant_ids = [];

        if ($product->get_children()) {
            $variant_ids = $product->get_children();

            foreach ($variant_ids as $variant_id) {
                $variant = wc_get_product($variant_id);

                if ($variant->get_image() == $image_id) {
                    $linked_variant_ids[] = syncerize_wc_generate_resource_id('variant', $variant_id);
                }
            }
        } else {
            // simple/variable product with no variation
            if ($product->get_image() == $image_id) {
                $linked_variant_ids[] = syncerize_wc_generate_resource_id('variant', $product->get_id());
            }
        }

        return $linked_variant_ids;
    }
}
