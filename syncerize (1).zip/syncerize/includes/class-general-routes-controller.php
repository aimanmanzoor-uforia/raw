<?php

namespace Syncerize\WooCommerce;

use Throwable;
use WP_REST_Controller;
use WP_REST_Response;
use WC_Customer;
use WP_REST_Request;
use WP_Error;

/**
 * General_Routes_Controller class.
 *
 * This class handles the registration of custom REST API routes for searching
 * customer information in a WooCommerce store. The routes are registered under
 * the namespace 'swc/v1'.
 */
class General_Routes_Controller extends WP_REST_Controller
{

    /**
     * Registers the routes for the custom REST API endpoints.
     *
     * This function registers a route for searching customer information based
     * on the customer ID.
     */
    public function register_routes()
    {
        $version   = '1';
        $namespace = 'swc/v' . $version;

        register_rest_route(
            $namespace,
            '/get-token',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'syncerize_wc_get_token'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/fetch-shop-detail',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'fetch_shop_detail'],
                'permission_callback' => '__return_true'
            )
        );
        register_rest_route(
            $namespace,
            '/set-store-type-in-woocommerce',
            array(
                'methods' => 'POST',
                'callback' => [$this, 'set_store_type_in_woocommerce'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/search-customer-by-email',
            [
                [
                    'methods' => 'GET',
                    'callback' => [$this, 'search_customer_by_email'],
                    'permission_callback' => '__return_true'
                ],
            ]
        );

        register_rest_route(
            $namespace,
            '/search-customer-by-phone',
            [
                [
                    'methods' => 'GET',
                    'callback' => [$this, 'search_customer_by_phone'],
                    'permission_callback' => '__return_true'
                ],
            ]
        );

        register_rest_route(
            $namespace,
            '/get-encoded-resource-id',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'get_encoded_resource_id'],
                'permission_callback' => '__return_true'
            )
        );

        register_rest_route(
            $namespace,
            '/get-decoded-resource-id',
            array(
                'methods' => 'GET',
                'callback' => [$this, 'get_decoded_resource_id'],
                'permission_callback' => '__return_true'
            )
        );
    }

    /**
     * This function is used to generate resource id
     *
     *
     * @param  WP_REST_Request  $request
     *
     * @return mixed
     */
    public function get_encoded_resource_id(WP_REST_Request $request)
    {
        try {
            return rest_ensure_response(
                [
                    "errors" => false,
                    "response" => [],
                    "status" => 200,
                    "body" => [
                        'resourceId' => syncerize_wc_generate_resource_id(
                            $request['resource_type'],
                            $request['resource_id']
                        )
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function is used to generate decoded resource id
     *
     *
     * @param  WP_REST_Request  $request
     *
     * @return mixed
     */
    public function get_decoded_resource_id(WP_REST_Request $request)
    {
        try {
            return rest_ensure_response(
                [
                    "errors" => false,
                    "response" => [],
                    "status" => 200,
                    "body" => [
                        'resourceId' => syncerize_wc_decode_resource_id($request['resource_id'])
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * Handles the Bearer token from the request, decodes it, and returns a new token.
     *
     * @param  WP_REST_Request  $request
     * @return WP_REST_Response
     */
    public function syncerize_wc_get_token(WP_REST_Request $request)
    {
        $headers     = getallheaders();
        $auth_header = $headers['Authorization'] ?? null; // Get authorization header
        $shop        = $request->get_param('store');  // Get token from query parameter

        // Check if the store is provided
        if (empty($shop)) {
            return new WP_REST_Response(array('error' => 'Store not provided'), 400);
        }


        // Check if the token is provided via Authorization header
        if (empty($auth_header) || strpos($auth_header, 'Bearer ') === false) {
            return new WP_REST_Response(array('error' => 'Bearer token not provided'), 400);
        }

        // Extract the token from the Authorization header
        $token = str_replace('Bearer ', '', $auth_header);

        try {
            // Check if shop is valid
            $shopId    = syncerize_wc_get_user_id_by_shop_name($shop);
            $shopPassw = get_option('_syncerize_' . $shop . '_shop_password');
            if (empty($shopId) || empty($shopPassw)) {
                return new WP_REST_Response(array('error' => 'Invalid Store provided'), 400);
            }

            // Check if token is valid
            if (!syncerize_wc_validate_token($token, $shopPassw)) {
                return new WP_REST_Response(array('error' => 'Invalid token provided'), 400);
            }

            // Generate new JWT token
            $payload  = [
                "user_id" => $shopId,
                "username" => $shop,
                "exp" => time() + 150, // Token expiration time (2.5 min)
            ];
            $tokenNew = syncerize_wc_create_jwt_token($payload, $shopPassw);

            // Return the new JWT token
            return new WP_REST_Response(array('token' => $tokenNew), 200);
        } catch (Throwable $e) {
            return new WP_REST_Response(array('error' => 'Invalid token: ' . $e->getMessage()), 400);
        }
    }

    /**
     * Search customer by email
     *
     * @param WP_REST_Request $request
     *
     * @return WP_REST_Response
     */
    public function search_customer_by_email($request)
    {
        $email = $request->get_param('email');

        if (empty($email)) {
            return rest_ensure_response(
                [
                    'status' => 500,
                    'errors' => true,
                    'message' => 'Email is empty'
                ]
            );
        }

        $customers = [];
        $user      = get_user_by('email', sanitize_email($email));
        if ($user) {
            $customer           = new WC_Customer($user->ID);
            $customers['nodes'] = [
                [
                    'legacyResourceId' => syncerize_wc_generate_resource_id('customer', $customer->get_id()),
                    'email' => $customer->get_email()
                ]
            ];
        } else {
            // For guest user
            /* global $wpdb;
             $max_attempts = 50;
             $attempts     = 0;
             while ($attempts < $max_attempts) {
                 $customer = $wpdb->get_row($wpdb->prepare("
                     SELECT * FROM {$wpdb->prefix}wc_customer_lookup
                     WHERE email = %s
                 ", sanitize_email($email)));
                 if (!empty($customer)) {
                     break; // Exit the loop if a customer is found
                 }
                 $attempts++;
                 usleep(3000000); // Sleep for 0.5 seconds before retrying
             }*/
//            $customers['nodes'] = [
//                'legacyResourceId' => $customer->customer_id,
//                'email' => $customer->email ?? ''
//            ];
        }


        return rest_ensure_response(
            [
                'errors' => false,
                'response' => [],
                'status' => 200,
                'body' => [
                    'data' => [
                        'customers' => $customers
                    ]

                ]
            ]
        );
    }

    /**
     * Search customer by phone
     *
     * @param WP_REST_Request $request
     *
     * @return WP_REST_Response
     */
    public function search_customer_by_phone($request)
    {
        $phone = $request->get_param('phone');

        if (empty($phone)) {
            return rest_ensure_response(
                [
                    'status' => 500,
                    'errors' => true,
                    'message' => 'Phone is empty'
                ]
            );
        }

        // @TODO: Implementation for later on
        $customers = [];

        return rest_ensure_response(
            [
                'errors' => false,
                'response' => [],
                'status' => 200,
                'body' => [
                    'data' => [
                        'customers' => $customers
                    ]

                ]
            ]
        );
    }

    /**
     * This function retrieves shop detail
     *
     *
     * @return mixed
     */
    public function fetch_shop_detail()
    {
        try {
            $user = get_users(
                array(
                    'role' => 'administrator',
                    'number' => 1 // Get only one admin user
                )
            )[0];

            $shopDetail = [];

            // format data
            $shopDetail['name']  = get_bloginfo('name');
            $shopDetail['email'] = $user->data->user_email;

            $shopDetail['currencyCode'] = get_woocommerce_currency();

            $shopDetail['billingAddress'] = [];

            $shopDetail['billingAddress']['address1'] = WC()->countries->get_base_address();
            $shopDetail['billingAddress']['city']     = WC()->countries->get_base_city();

            $shopDetail['billingAddress']['country']  = WC()->countries->get_base_country();
            $shopDetail['billingAddress']['province'] = WC()->countries->get_base_state();

            $shopDetail['billingAddress']['phone'] = get_user_meta($user->data->ID, 'billing_phone', true);
            $shopDetail['billingAddress']['zip']   = WC()->countries->get_base_postcode();


            $response = [
                'errors' => false,
                'status' => 200,
                'body' => [
                    'data' => [
                        'shop' => $shopDetail,
                    ],
                ],
            ];

            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function sets store type in option
     *
     * @param $request
     *
     * @return mixed
     */
    public function set_store_type_in_woocommerce($request)
    {
        try {
            $store     = $request->get_param('shop');
            $storeType = $request->get_param('type');

            // Check if the store is provided
            if (!empty($store)) {
                update_option('_syncerize_' . $store . '_shop_type', $storeType);
            }

            $response = [
                'errors' => false,
                'status' => 200,
                'body' => [
                    'data' => [
                        'storeType' => $storeType,
                    ],
                ],
            ];

            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

}
