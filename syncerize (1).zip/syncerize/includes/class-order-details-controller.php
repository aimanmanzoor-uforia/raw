<?php

namespace Syncerize\WooCommerce;

use Throwable;
use stdClass;
use WP_REST_Controller;
use WP_REST_Response;
use WC_Customer;
use WP_REST_Request;
use WC_Order_Item_Product;
use WC_Order_Item_Shipping;

/**
 * Order_Details_Controller class.
 *
 * This class handles the registration of custom REST API routes for retrieving
 * order details in a WooCommerce store. The routes are registered under the
 * namespace 'swc/v1'.
 */
class Order_Details_Controller extends WP_REST_Controller
{

    /**
     * Registers the routes for the custom REST API endpoints.
     *
     * This function registers a route for retrieving order details based on
     * the order ID.
     */
    public function register_routes()
    {
        $version   = '1';
        $namespace = 'swc/v' . $version;

        register_rest_route(
            $namespace,
            '/fetch-order/',
            [
                [
                    'methods' => 'GET',
                    'callback' => [$this, 'fetch_order_details'],
                    'permission_callback' => '__return_true',
                ],
            ]
        );

        register_rest_route(
            $namespace,
            '/order-create-manual/',
            [
                'methods' => 'POST',
                'callback' => [$this, 'order_create_manual'],
                'permission_callback' => '__return_true', // Change this to check permissions if needed
                'args' => [
                    'orderId' => [
                        'required' => true,
                        'validate_callback' => function ($param, $request, $key) {
                            return is_numeric($param); // or other validation logic
                        }
                    ],
                    'order' => [
                        'required' => true
                    ]
                ],
            ]
        );

        register_rest_route(
            $namespace,
            '/create-draft-order/',
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_draft_order'],
                'permission_callback' => '__return_true', // Change this to check permissions if needed
            ]
        );

        register_rest_route(
            $namespace,
            '/update-draft-order/',
            [
                'methods' => 'POST',
                'callback' => [$this, 'update_draft_order'],
                'permission_callback' => '__return_true', // Change this to check permissions if needed
            ]
        );

        register_rest_route(
            $namespace,
            '/complete-draft-order/',
            [
                'methods' => 'POST',
                'callback' => [$this, 'complete_draft_order'],
                'permission_callback' => '__return_true', // Change this to check permissions if needed
            ]
        );

        register_rest_route(
            $namespace,
            '/cancel-order/',
            [
                'methods' => 'POST',
                'callback' => [$this, 'cancel_order'],
                'permission_callback' => '__return_true', // Change this to check permissions if needed
            ]
        );

        register_rest_route(
            $namespace,
            '/update-order/',
            [
                'methods' => 'POST',
                'callback' => [$this, 'update_order'],
                'permission_callback' => '__return_true', // Change this to check permissions if needed
            ]
        );

        register_rest_route(
            $namespace,
            '/fetch-fulfillment-order/',
            [
                [
                    'methods' => 'GET',
                    'callback' => [$this, 'fetch_fulfillment_order'],
                    'permission_callback' => '__return_true',
                ],
            ]
        );

        register_rest_route(
            $namespace,
            '/create-fulfillment-order/',
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_fulfillment_order'],
                'permission_callback' => '__return_true', // Change this to check permissions if needed
            ]
        );

        register_rest_route(
            $namespace,
            '/update-fulfillment-tracking-info/',
            [
                'methods' => 'POST',
                'callback' => [$this, 'update_fulfillment_tracking_info'],
                'permission_callback' => '__return_true',
            ]
        );
    }

    /**
     * Create order manually
     *
     * @param $request
     */
    public function order_create_manual($request)
    {
        $order_id = $request->get_param('orderId');
        $order    = $request->get_param('order');

        syncerize_wc_order_create($order_id, $order);
    }

    /**
     * This function gets order notes
     *
     * @param $order_id
     * @param $type
     *
     * @return array
     */
    private function get_order_notes($order_id, $type = null): array
    {
        $params = [
            'order_id' => $order_id
        ];

        if ($type) {
            $params['type'] = $type;
        }

        return wc_get_order_notes($params);
    }

    /**
     * Get line item discount
     *
     * @param $line_item
     *
     * @return mixed
     */
    private function get_line_item_discount($line_item)
    {
        // Price before discount
        $subtotal = $line_item->get_subtotal();

        // Price after discount
        $total = $line_item->get_total();

        // Discount at line item level
        return $subtotal - $total;
    }

    /**
     * Retrieves order details based on the provided order ID.
     *
     * This function fetches order details from WooCommerce based on the
     * provided order ID. It returns information such as order number,
     * financial status, total price, customer details, shipping address,
     * shipping lines, and line items.
     *
     * @param WP_REST_Request $request The request object containing the order ID.
     *
     * @return WP_REST_Response|array The response object containing the order
     *     details or an error message.
     */
    public function fetch_order_details(WP_REST_Request $request)
    {
        try {
            $order_id            = syncerize_wc_decode_resource_id($request['orderId']);
            $customer_first_name = get_post_meta($order_id, '_customer_first_name', true);
            $customer_last_name  = get_post_meta($order_id, '_customer_last_name', true);

            // Fetch order details
            $order = wc_get_order($order_id);

            if (!$order) {
                return rest_ensure_response(
                    [
                        'errors' => true,
                        'status' => 404,
                        'exception' => [
                            'message' => 'Order not found.'
                        ]
                    ]
                );
            }

            if (!$order->get_items()) {
                return rest_ensure_response(
                    [
                        'errors' => true,
                        'status' => 404,
                        'exception' => [
                            'message' => 'Order line items not found.'
                        ]
                    ]
                );
            }

            // Shipping Address
            $shipping_address = $order->get_address('shipping');

            $shipping_address['address1'] = $shipping_address['address_1'];
            unset($shipping_address['address_1']);

            $shipping_address['address2'] = $shipping_address['address_2'];
            unset($shipping_address['address_2']);

            $shipping_address['zip'] = $shipping_address['postcode'];
            unset($shipping_address['postcode']);

            $shipping_address['country_code'] = $shipping_address['country'];
            $shipping_address['name']         = $shipping_address['first_name'] . ' ' . $shipping_address['last_name'];

            // Billing Address
            $billing_address             = $order->get_address('billing');
            $billing_address['address1'] = $billing_address['address_1'];
            unset($billing_address['address_1']);

            $billing_address['address2'] = $billing_address['address_2'];
            unset($billing_address['address_2']);

            $billing_address['zip'] = $billing_address['postcode'];
            unset($billing_address['postcode']);

            $billing_address['country_code'] = $billing_address['country'];
            $billing_address['name']         = $billing_address['first_name'] . ' ' . $billing_address['last_name'];

            $shipping_lines      = $order->get_shipping_methods();
            $shipping_lines_data = [];

            $count_shipping_lines = 0;

            $order_currency = $order->get_currency();

            $total_shipping_price_set = [
                'shop_money' => [
                    'amount' => 0.00,
                    'currency_code' => $order_currency
                ],
                'presentment_money' => [
                    'amount' => 0.00,
                    'currency_code' => $order_currency
                ]
            ];

            foreach ($shipping_lines as $shipping_line) {
                $shipping_line_data = $shipping_line->get_data();

                $shipping_lines_data[$count_shipping_lines]['code']  = $shipping_line_data['method_id'];
                $shipping_lines_data[$count_shipping_lines]['title'] = $shipping_line_data['method_title'];

                $shipping_lines_data[$count_shipping_lines]['price'] = syncerize_wc_convert_number_format(
                    $shipping_line_data['total']
                );

                $total_shipping_price_set['shop_money']['amount']        += $shipping_lines_data[$count_shipping_lines]['price'];
                $total_shipping_price_set['presentment_money']['amount'] += $shipping_lines_data[$count_shipping_lines]['price'];

                $count_shipping_lines++;
            }

            // Get order data
            $orderData = $order->get_data();

            // Get order items
            $order_items = $order->get_items();

            $items_data = [];
            foreach ($order_items as $item) {
                // fetch product
                $product = $item->get_product();
                $sku     = '';

                // Check if the product exists
                if ($product) {
                    // Get the SKU
                    $sku = $product->get_sku();
                }

                /*          -------- For Discount calculation ---------
                            // Get the line item subtotal and total
                            $subtotal = $item->get_subtotal(); // Subtotal before discounts
                            $total = $item->get_total(); // Total after discounts

                            // Get the order's total tax amount
                            $taxes = $order->get_total_tax();

                            // Get shipping discount (if applicable)
                            $shipping_discount = 0;
                            if ( $order->get_discount_total() > 0 ) {
                                // Fetch the shipping discount from the order discounts
                                $shipping_discount = $order->get_shipping_discount(); // Adjust this line as needed based on your implementation
                            }

                            // Calculate the discount considering subtotal, total, taxes, and shipping discount
                            $discount = $subtotal - $total + $taxes + $shipping_discount;*/

                $variant_id = $item->get_variation_id() ?: $item->get_product_id();

                $order_line_item_id       = syncerize_wc_generate_resource_id('lineItem', $item->get_id());
                $total_line_item_discount = $this->get_line_item_discount($item);

                // items data
                $items_data[] = [
                    'admin_graphql_api_id' => 'gid://woocommerce/LineItem/' . $order_line_item_id,
                    'id' => $order_line_item_id,
                    'product_id' => syncerize_wc_generate_resource_id('product', $item->get_product_id()),
                    'name' => $item->get_name(),
                    'title' => $item->get_name(),
                    'quantity' => $item->get_quantity(),
                    'variant_id' => syncerize_wc_generate_resource_id('variant', $variant_id),
                    'price' => $order->get_line_subtotal($item, false, false) / $item->get_quantity(),
                    'fulfillment_status' => $orderData['status'] == 'completed' ? 'fulfilled' : null,
                    'price_set' => null,
                    'properties' => [],
                    'sku' => $sku,
                    'total_discount' => '0.00',
                    'total_discount_set' => null,
//                'tax_lines' => $item->get_taxes(),
                    'tax_lines' => [],
                    'discount_allocations' => ($total_line_item_discount > 0) ? [['amount' => $total_line_item_discount]] : []
                ];
            }

            // Separate customer notes and private notes
            $customer_notes = $this->get_order_notes($order_id, 'customer');
            $customer_notes = array_column($customer_notes, 'content');

            $private_notes = $this->get_order_notes($order_id, 'internal');
            $private_notes = array_column($private_notes, 'content');

            $note_attributes = [];
            $count           = 0;
            foreach ($private_notes as $private_note) {
                // Check if the note is not system-generated
                if (preg_match('/Order status changed|Added line items|Stock levels reduced/', $private_note)) {
                    continue;
                }

                $note = new stdClass();

                if (strpos($private_note, ': ') !== false) {
                    $new_note    = explode(': ', $private_note, 2);
                    $note->name  = $new_note[0] ?: '_attribute_' . (++$count);
                    $note->value = $new_note[1];
                } else {
                    $note->name  = '_attribute_' . (++$count);
                    $note->value = $private_note;
                }

                $note_attributes[] = $note;
            }


            $orderUniqueId = syncerize_wc_generate_resource_id('order', $order_id);

            $app_id = (int)$order->get_meta('_syncerize_app_id');

            $financial_status = 'pending';
            if ($order->is_paid()) {
                $financial_status = 'paid';
            }


            $fulfillments = [];

            // If order is fulfilled add fulfillments
            if ($orderData['status'] == 'completed') {
                $fulfillment_id = syncerize_wc_generate_unique_id();

                $fulfillments[] = [
                    'id' => $fulfillment_id,
                    'admin_graphql_api_id' => "gid://woocommerce/Fulfillment/$fulfillment_id",
                    'created_at' => date('c'),
                    'location_id' => syncerize_wc_generate_unique_id(),
                    'name' => "#$order_id.1",
                    'order_id' => $request['orderId'],
                    'origin_address' => [],
                    'receipt' => [],
                    'service' => 'manual',
                    'shipping_status' => null,
                    'status' => 'success',
                    'tracking_company' => null,
                    'tracking_number' => null,
                    'tracking_numbers' => [],
                    'tracking_urls' => null,
                    'updated_at' => date('c'),
                    'line_items' => $items_data
                ];
            }

            // Get order data
            $order_data = [
                'admin_graphql_api_id' => 'gid://woocommerce/Order/' . $orderUniqueId,
                'id' => $orderUniqueId,
                'app_id' => !empty($app_id) ? $app_id : (int)syncerize_wc_generate_unique_id(),
                'company' => null,
                'order_number' => $orderData['number'],
                'financial_status' => $financial_status,
                'fulfillment_status' => $orderData['status'] == 'completed' ? 'fulfilled' : null,
                'name' => '#' . $orderData['number'],
                'current_subtotal_price' => syncerize_wc_convert_number_format($order->get_subtotal()),
                'subtotal_price' => syncerize_wc_convert_number_format($order->get_subtotal()),
                'current_total_price' => syncerize_wc_convert_number_format($orderData['total']),
                'total_price' => syncerize_wc_convert_number_format($orderData['total']),
                'current_total_tax' => syncerize_wc_convert_number_format($orderData['total_tax']),
                'total_tax' => syncerize_wc_convert_number_format($orderData['total_tax']),
//            'price_without_tax' => $orderData['total'] - $orderData['total_tax'],
                'note' => implode(' | ', $customer_notes),
                'note_attributes' => $note_attributes,
                'created_at' => $orderData['date_created']->date('Y-m-d H:i:s'),
                'updated_at' => syncerize_wc_get_object_modified_at_datetime_in_utc($order),
                'currency' => $orderData['currency'],
                'tags' => $order->get_meta('_tags'),
                'properties' => [],
                'email' => $orderData['billing']['email'],
                'contact_email' => $orderData['billing']['email'],
                'phone' => $orderData['billing']['phone'],
                'customer' => [
                    'admin_graphql_api_id' => 'gid://woocommerce/Customer/' . $orderData['customer_id'],
                    'id' => syncerize_wc_generate_resource_id('customer', $orderData['customer_id']),
                    'email' => $orderData['billing']['email'],
                    'first_name' => $customer_first_name ?: $orderData['billing']['first_name'],
                    'last_name' => $customer_last_name ?: $orderData['billing']['last_name'],
                    'state' => 'enabled',
                    'note' => null,
                    'tags' => '',
                    'verified_email' => true,
                    'multipass_identifier' => null,
                    'tax_exempt' => false,
                    'phone' => $orderData['billing']['phone'],
                    'currency' => $orderData['currency'],
                    'default_address' => [
                        'id' => uniqid(),
                        'customer_id' => syncerize_wc_generate_resource_id('customer', $orderData['customer_id']),
                        'first_name' => $customer_first_name ?: $orderData['billing']['first_name'],
                        'last_name' => $customer_last_name ?: $orderData['billing']['last_name'],
                        'name' => $orderData['billing']['first_name'] . $orderData['billing']['last_name'],
                        'company' => null,
                        'address1' => $orderData['billing']['address_1'],
                        'address2' => $orderData['billing']['address_2'],
                        'city' => $orderData['billing']['city'],
                        'province' => $orderData['billing']['state'],
                        'country' => $orderData['billing']['country'],
                        'zip' => $orderData['billing']['postcode'],
                        'phone' => $orderData['billing']['phone'],
                        'country_code' => $orderData['billing']['country'],
                        'default' => true,
                    ],
                ],
                'shipping_address' => $shipping_address,
                'billing_address' => $billing_address,
                'shipping_lines' => $shipping_lines_data,
                'line_items' => $items_data,
                'tax_lines' => $orderData['tax_lines'],
                'taxes_included' => $orderData['prices_include_tax'],
                'discount_codes' => [],
                'total_discounts' => syncerize_wc_convert_number_format($orderData['discount_total']),
                'total_shipping_price_set' => $total_shipping_price_set,
                'discount_applications' => [],
                'fulfillments' => $fulfillments,
                'refunds' => []
            ];


            $response = [
                'errors' => false,
                'response' => [],
                'status' => 200,
                'body' => [
                    'order' => $order_data,
                ],
            ];

            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * This function updates order notes
     *
     * @param $request
     * @return mixed
     */
    public function update_order($request)
    {
        try {
            $payload  = $request['payload']['input'];
            $order_id = $payload['id'];
            syncerize_wc_convert_gid_to_id($order_id);

            $order_id = syncerize_wc_decode_resource_id($order_id);
            $order    = wc_get_order($order_id);

            $notes = $this->get_order_notes($order_id);

            // Deleting all old notes
            foreach ($notes as $note) {
                wp_delete_comment($note->id, true);
            }

            // Adding new customer note
            if (!empty($payload['note'])) {
                $order->add_order_note($payload['note'], true);
            }

            // Adding new private notes
            foreach ($payload['customAttributes'] as $note_attribute) {
                // Check if its not system-generated
                if (!preg_match(
                    '/Order status changed|Added line items|Stock levels reduced/',
                    $note_attribute['value']
                )) {
                    $order->add_order_note($note_attribute['key'] . ': ' . $note_attribute['value']);
                }
            }

            $order->save();

            return rest_ensure_response(
                [
                    'errors' => false,
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'orderUpdate' => [
                                'order' => [
                                    'id' => 'gid://woocommerce/Order/' . $request['orderId']
                                ],
                                'userErrors' => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * Creates Draft order in woocommerce
     *
     *
     * @param  WP_REST_Request  $request  The request object containing the order data
     *
     * @return WP_REST_Response|array The response object containing the draft order id
     *
     */
    public function create_draft_order(WP_REST_Request $request)
    {
        try {
            // Extract order data from payload
            $order_data       = $request['bulkOrderData']['draft_order'];
            $customer_data    = $order_data['customer'];
            $shipping_address = $order_data['shipping_address'];
            $billing_address  = $order_data['billing_address'];
            $line_items       = $order_data['line_items'];
            $note_attributes  = $order_data['note_attributes'];

            // Check if customer id given
            if (!empty($customer_data['id'])) {
                $customer_id = syncerize_wc_decode_resource_id($customer_data['id']);
                $customer    = new WC_Customer($customer_id);

                // Update customer details
                $customer->set_first_name($customer_data['first_name']);
                $customer->set_last_name($customer_data['last_name']);
                $customer->set_email($customer_data['email']);
                $customer->save();
            } elseif (empty($customer_data['email'])) {
                // Check if customer email not provided
                return rest_ensure_response(
                    [
                        'errors' => true,
                        'response' => [],
                        'status' => 500,
                        'body' => [
                            'customer.base' => [
                                '0' => 'Customer must have a name, phone number or email address'
                            ]
                        ]
                    ]
                );
            } else {
                // Create a new customer
                $customer = new WC_Customer();
                $customer->set_first_name($customer_data['first_name']);
                $customer->set_last_name($customer_data['last_name']);
                $customer->set_email($customer_data['email']);
                $customer->set_username(sanitize_user($customer_data['email']));

                // Set a password if needed, or generate one
                $password = wp_generate_password();
                $customer->set_password($password);
                $customer->save();

                $customer_id = $customer->get_id();
            }

            // Create the order with default 'pending' status for draft purposes
            $draftOrder = wc_create_order(['status' => 'checkout-draft']);

            // Add syncerize app id
            global $config_syncerize;

            $draftOrder->update_meta_data('_syncerize_app_id', $config_syncerize['APP_ID']);

            // Creating private order custom fields for customer
            update_post_meta($draftOrder->get_id(), '_customer_first_name', $customer_data['first_name']);
            update_post_meta($draftOrder->get_id(), '_customer_last_name', $customer_data['last_name']);

            // Assign the customer to the order
            $draftOrder->set_customer_id($customer_id);

            $draftOrder->set_billing_email($order_data['email']);

            $draftOrder->set_billing_first_name($billing_address['first_name'] ?? '');
            $draftOrder->set_billing_last_name($billing_address['last_name'] ?? '');
            $draftOrder->set_billing_address_1($billing_address['address1'] ?? '');
            $draftOrder->set_billing_city($billing_address['city'] ?? '');
            $draftOrder->set_billing_postcode($billing_address['zip'] ?? '');
            $draftOrder->set_billing_country($billing_address['country'] ?? '');
            $draftOrder->set_shipping_first_name($shipping_address['first_name'] ?? '');
            $draftOrder->set_shipping_last_name($shipping_address['last_name'] ?? '');
            $draftOrder->set_shipping_address_1($shipping_address['address1'] ?? '');
            $draftOrder->set_shipping_city($shipping_address['city'] ?? '');
            $draftOrder->set_shipping_postcode($shipping_address['zip'] ?? '');
            $draftOrder->set_shipping_country($shipping_address['country'] ?? '');

            // Set order notes in Customer Notes and tags
            if (!empty($order_data['note'])) {
                $draftOrder->add_order_note($order_data['note'], true);
            }
            if (!empty($order_data['tags'])) {
                $draftOrder->update_meta_data('_tags', $order_data['tags']);
            }

            // Add note attributes in Private Notes
            foreach ($note_attributes as $attribute) {
                $draftOrder->add_order_note($attribute['name'] . ': ' . $attribute['value']);
            }

            // Add line items
            foreach ($line_items as $item) {
                $variation_id = syncerize_wc_decode_resource_id($item['variant_id']);
                $product      = wc_get_product($variation_id);

                if ($product) {
                    if ($product->is_type('variation')) {
                        $product_id = $product->get_parent_id(); // Get the main product ID from the variation
                    } else {
                        $product_id = $variation_id;
                    }
                } else {
                    // Delete the draft order
                    $draftOrder->delete(true);

                    // Product/Variation not found
                    return rest_ensure_response(
                        [
                            'errors' => true,
                            'response' => [],
                            'status' => 500,
                            'body' => [
                                'base' => [
                                    '0' => 'Product/Variant(s) not found.'
                                ]
                            ]
                        ]
                    );
                }

                $quantity = $item['quantity'];
                $price    = (int)$product->get_price();

                $order_item = new WC_Order_Item_Product();
                $order_item->set_product_id($product_id);
                $order_item->set_name($product->get_name());

                if ($product->is_type('variation')) {
                    $order_item->set_variation_id($variation_id);
                }

                $applied_discount = $item['applied_discount']['value'] ?? 0;

                $order_item->set_quantity($quantity);
                $order_item->set_subtotal($price * $quantity);
                $order_item->set_total(($price * $quantity) - ($applied_discount * $quantity));

                // Add custom properties as metadata for each item
                foreach ($item['properties'] as $property) {
                    $order_item->add_meta_data($property['name'], $property['value']);
                }

                $draftOrder->add_item($order_item);
            }

            // Set shipping method details
            if (!empty($order_data['shipping_line'])) {
                $shipping_line = $order_data['shipping_line'];
                $shipping_item = new WC_Order_Item_Shipping();
                $shipping_item->set_method_title($shipping_line['title']);
                $shipping_item->set_total($shipping_line['price']);
                $draftOrder->add_item($shipping_item);
            }

            // Save the order
            $draftOrder->calculate_totals();
            $draftOrder->save();


            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 201,
                    'body' => [
                        'draft_order' => [
                            'id' => syncerize_wc_generate_resource_id('draftOrder', $draftOrder->get_id())
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            if (isset($draftOrder) && $draftOrder instanceof WC_Order && $draftOrder->get_id()) {
                $draftOrder->delete(true);
            }

            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * Updates Draft order in woocommerce
     *
     *
     * @param WP_REST_Request $request
     *
     * @return WP_REST_Response|array
     *
     */
    public function update_draft_order(WP_REST_Request $request)
    {
        try {
            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'draftOrderUpdate' => [
                                'draftOrder' => [
                                    'id' => str_replace('shopify', 'woocommerce', $request['payload']['id']),
                                ]
                            ],
                            'userErrors' => []
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * Completes Draft order in woocommerce
     *
     * This function updates draft order status from 'Draft' to 'Processing' or 'Pending Payment'
     *
     * @param WP_REST_Request $request The request object containing the order data
     *
     * @return WP_REST_Response|array The response object containing the order id
     *
     */
    public function complete_draft_order(WP_REST_Request $request)
    {
        try {
            // Extract order data from payload
            $draft_order_id  = syncerize_wc_decode_resource_id($request['draftOrderId']);
            $payment_pending = $request['draftOrderData']['payment_pending'];

            // Load the order using the draft order ID
            $draftOrder = wc_get_order($draft_order_id);

            if (!$draftOrder) {
                return rest_ensure_response(
                    [
                        'errors' => true,
                        'status' => 404,
                        'exception' => [
                            'message' => 'Draft Order not found'
                        ]
                    ]
                );
            }

            // Set order status based on payment pending status
            if ($payment_pending) {
                $draftOrder->set_status('payment-pending');
            } else {
                $draftOrder->set_status('processing');
            }

            // Save the order
            $draftOrder->save();

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'draft_order' => [
                            'order_id' => syncerize_wc_generate_resource_id('order', $draftOrder->get_id())
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * Cancels order in woocommerce
     *
     * This function updates order status to 'cancelled'
     *
     * @param  WP_REST_Request  $request  The request object containing the order data
     *
     * @return WP_REST_Response|array The response object containing the order id
     *
     */
    public function cancel_order(WP_REST_Request $request)
    {
        try {
            // Extract order data from payload
            $order_id = syncerize_wc_decode_resource_id($request['orderId']);

            // Retrieve order
            $order = wc_get_order($order_id);

            if (!$order) {
                return rest_ensure_response(
                    [
                        'errors' => true,
                        'status' => 404,
                        'exception' => [
                            'message' => 'Order not found.'
                        ]
                    ]
                );
            }

            // Update order status to 'cancelled'
            $order->update_status('cancelled', 'Order is cancelled by Syncerize.');

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'orderCancel' => [
                                'job' => [
                                    'done' => true
                                ],
                                'userErrors' => []
                            ],
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * Retrieves order fulfillment
     *
     * This function fetches order fulfillments from WooCommerce based on the
     * provided order ID.
     *
     * @param  WP_REST_Request  $request  The request object containing the order ID.
     *
     * @return WP_REST_Response|array The response object containing the order
     *     details or an error message.
     */
    public function fetch_fulfillment_order(WP_REST_Request $request)
    {
        try {
            $order_id = syncerize_wc_decode_resource_id($request['orderId']);

            // Fetch order details
            $order = wc_get_order($order_id);

            if (!$order) {
                return rest_ensure_response(
                    [
                        'errors' => true,
                        'status' => 404,
                        'exception' => [
                            'message' => 'Order not found.'
                        ]
                    ]
                );
            }

            // Get order items
            $order_items = $order->get_items();

            $items_data = [];
            foreach ($order_items as $item) {
                $variant_id = $item->get_variation_id() ?: $item->get_product_id();

                $order_line_item_id = syncerize_wc_generate_resource_id('lineItem', $item->get_id());

                $items_data[] = [
                    'id' => (int)syncerize_wc_generate_unique_id(),
                    'lineItem' => ['id' => $order_line_item_id],
                    'totalQuantity' => $item->get_quantity(),
                    'inventoryItemId' => (int)syncerize_wc_generate_unique_id(),
                    'variant' => [
                        'id' => syncerize_wc_generate_resource_id('variant', $variant_id)
                    ]
                ];
            }

            // Get order fulfillment data
            $order_fulfillment_data = [
                'nodes' => [
                    'container' => [
                        'id' => (int)syncerize_wc_generate_unique_id(),
                        'lineItems' => ['nodes' => ['container' => $items_data]]
                    ]
                ]
            ];

            $response = [
                'errors' => false,
                'response' => [],
                'status' => 200,
                'body' => [
                    'data' => [
                        'order' => [
                            'fulfillmentOrders' => $order_fulfillment_data,
                        ]
                    ]
                ],
            ];

            return rest_ensure_response($response);
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    /**
     * Creates fulfillment order in woocommerce
     *
     * This function updates order status to 'completed'
     *
     * @param  WP_REST_Request  $request  The request object containing the order data
     *
     * @return WP_REST_Response|array The response object containing the order id
     *
     */
    public function create_fulfillment_order(WP_REST_Request $request)
    {
        try {
            $order_id           = $request['orderId'];
            $fulfillment_status = $request['fulfillmentStatus'];
            // Check if empty order id or fulfillment status is not fulfilled
            if (empty($order_id) || empty($fulfillment_status) || $fulfillment_status != 'fulfilled') {
                return rest_ensure_response(
                    [
                        'errors' => false,
                        'response' => [],
                        'status' => 200,
                        'body' => [
                            'data' => [
                                'fulfillmentCreateV2' => [
                                    'fulfillment' => false,
                                    'userErrors' => []
                                ]
                            ]
                        ]
                    ]
                );
            }

            // Extract order data from payload
            $order_id = syncerize_wc_decode_resource_id($order_id);

            // Retrieve order
            $order = wc_get_order($order_id);

            if (!$order) {
                return rest_ensure_response(
                    [
                        'errors' => true,
                        'status' => 404,
                        'exception' => [
                            'message' => 'Order not found.'
                        ]
                    ]
                );
            }

            // Update order status to 'completed'
            $order->update_status('completed', 'Order is completed by Syncerize.');

            // Add tracking after status update
            $payload = $request['payload'];
            if (!empty($payload['fulfillment']['trackingInfo']['numbers'])) {
                foreach ($payload['fulfillment']['trackingInfo']['numbers'] as $index => $tracking_number) {
                    if (!empty($tracking_number)) {
                        $order->update_meta_data('tracking_number_' . ($index + 1), sanitize_text_field($tracking_number));
                    }
                }
            }

            // Save meta data
            $order->save();

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'fulfillmentCreateV2' => [
                                'fulfillment' => [
                                    'id'    => 'gid://woocommerce/Fulfillment/' . syncerize_wc_generate_unique_id(),
                                    'order' => [
                                        'id' => 'gid://woocommerce/Order/' . $request['orderId']
                                    ]
                                ],
                                'userErrors' => []
                            ]
                        ]
                    ]
                ]
            );
        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }

    public function update_fulfillment_tracking_info(WP_REST_Request $request)
    {
        try {
            $order_id = $request['orderId'];
            $payload = $request['payload'];

            // Extract order data from payload
            $order_id = syncerize_wc_decode_resource_id($order_id);

            // Retrieve order
            $order = wc_get_order($order_id);

            if (!$order) {
                return rest_ensure_response(
                    [
                        'errors' => true,
                        'status' => 404,
                        'exception' => [
                            'message' => 'Order not found.'
                        ]
                    ]
                );
            }

            // Clear all previous tracking_number_* meta first
            foreach ($order->get_meta_data() as $meta) {
                if (strpos($meta->key, 'tracking_number_') === 0) {
                    $order->delete_meta_data($meta->key);
                }
            }

            // Then add current ones
            if (!empty($payload['trackingInfoInput']['numbers'])) {
                foreach ($payload['trackingInfoInput']['numbers'] as $index => $tracking_number) {
                    if (!empty($tracking_number)) {
                        $order->update_meta_data('tracking_number_' . ($index + 1), sanitize_text_field($tracking_number));
                    }
                }
            }

            // Save meta data
            $order->save();

            return rest_ensure_response(
                [
                    'errors' => false,
                    'response' => [],
                    'status' => 200,
                    'body' => [
                        'data' => [
                            'fulfillmentTrackingInfoUpdate' => [
                                'fulfillment' => [
                                    'id'    => 'gid://woocommerce/Fulfillment/' . syncerize_wc_generate_unique_id(),
                                ],
                                'userErrors' => []
                            ]
                        ]
                    ]
                ]
            );

        } catch (Throwable $exception) {
            return syncerize_wc_error_response($exception);
        }
    }
}
