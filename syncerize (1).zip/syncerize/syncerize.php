<?php

/*
Plugin Name: Syncerize
Plugin URI: https://syncerize.com/
Description: Real-time Multi-store Inventory Syncing Plugin
Version: 1.2.51
Author: Uforia Infotech Inc
Author URI: https://uforiainfotech.com/
Requires Plugins: woocommerce
*/

global $plugin_file_url;
$plugin_file_url = __FILE__;

// Require necessary classes and functions
require_once plugin_dir_path(__FILE__) . 'includes/class-product-details-controller.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-order-details-controller.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-general-routes-controller.php';
require_once plugin_dir_path(__FILE__) . 'functions.php';
require_once plugin_dir_path(__FILE__) . 'hooks.php';
require_once plugin_dir_path(__FILE__) . 'config.php';

use Syncerize\WooCommerce\Product_Details_Controller;
use Syncerize\WooCommerce\Order_Details_Controller;
use Syncerize\WooCommerce\General_Routes_Controller;

// Include the configuration file for plugin settings
$config_syncerize = include(plugin_dir_path(__FILE__) . 'config.php');

$shop = syncerize_wc_get_shop();

// Add custom admin menu
add_action('admin_menu', 'syncerize_wc_syncerize_add_admin_menu');

// Remove first menu 'Dashboard'
add_action('admin_head', 'syncerize_hide_dashboard_menu');

/**
 * This function hides dashboard menu items
 */
function syncerize_hide_dashboard_menu()
{
    echo '<style>
        #toplevel_page_syncerize-admin ul.wp-submenu li.wp-first-item {
            display: none;
        }
    </style>';
}

/**
 * This function fetches the plugin update information from a remote server
 *
 * @return mixed
 */
function syncerize_wc_get_remote_plugin_update_info()
{
    global $config_syncerize;

    // Append param as a cache buster
    $url = add_query_arg('x', time(), $config_syncerize['PLUGIN_UPDATE_URL']);

    $response = wp_remote_get(
        $url,
        [
            'timeout' => 15,
            'sslverify' => false,
            'headers' => [
                'User-Agent' => 'Syncerize/1.0; ' . get_bloginfo('url'),
            ],
        ]
    );

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) != 200) {
        $error_message = $response->get_error_message();
        syncerize_wc_log('Failed to fetch plugin update information: ' . $error_message, 'error');
        return null;
    }

    return json_decode(wp_remote_retrieve_body($response));
}

/**
 * This function checks for plugin updates by comparing the version number
 *
 * @param $checked_data
 *
 * @return mixed
 */
function syncerize_wc_check_for_plugin_update($checked_data)
{
    if (empty($checked_data->checked)) {
        return $checked_data;
    }

    $plugin_slug = plugin_basename(__FILE__);
    $update_info = syncerize_wc_get_remote_plugin_update_info();

    if (isset($checked_data->checked[$plugin_slug]) && !empty($update_info)
        && version_compare($update_info->version, $checked_data->checked[$plugin_slug], '>')) {
        $checked_data->response[$plugin_slug] = (object)array(
            'slug' => $plugin_slug,
            'new_version' => $update_info->version,
            'url' => $update_info->download_url,
            'package' => $update_info->download_url,
        );
    }

    return $checked_data;
}

/**
 * This function fetches the plugin update information from a remote server
 *
 * @param $res
 * @param $action
 * @param $args
 *
 * @return mixed
 */
function syncerize_wc_plugin_api_call($res, $action, $args)
{
    if ($action !== 'plugin_information' || $args->slug !== plugin_basename(__FILE__)) {
        return $res;
    }

    $plugin_info = syncerize_wc_get_remote_plugin_update_info();

    return (object)[
        'name' => 'Syncerize',
        'slug' => plugin_basename(__FILE__),
        'version' => $plugin_info->version,
        'sections' => [
            'description' => $plugin_info->sections->description,
        ],
    ];
}

/**
 * Enqueue plugin-specific JavaScript.
 */
function syncerize_wc_enqueue_scripts($hook)
{
    // Register the script
    wp_register_script(
        'syncerize-woocommerce-scripts', // Handle
        plugin_dir_url(__FILE__) . 'js/syncerize-custom.js',
        // Path to the script
        [],
        '1.0.0', // Version (optional)
        true // Load in footer (optional)
    );

    // Enqueue the script
    wp_enqueue_script('syncerize-woocommerce-scripts');

    // Hide all admin notices in our plugin for fixing hidden Toast messages in Polaris
    if (strpos($hook, 'syncerize') !== false) {
        echo '<style>
        .notice, .update-nag {
            display: none !important;
        }
    </style>';
    }
}

add_action('admin_enqueue_scripts', 'syncerize_wc_enqueue_scripts');


/**
 * Initializes the Product Details Controller.
 * This controller handles the registration of routes for product-related actions.
 *
 * @return void
 */
function syncerize_wc_initialize_product_details_controller()
{
    $controller = new Product_Details_Controller();
    $controller->register_routes();
}

add_action('rest_api_init', 'syncerize_wc_initialize_product_details_controller');


/**
 * Initializes the Order Details Controller.
 * This controller handles the registration of routes for order-related actions.
 *
 * @return void
 */
function syncerize_wc_initialize_order_details_controller()
{
    $order_controller = new Order_Details_Controller();
    $order_controller->register_routes();
}

add_action('rest_api_init', 'syncerize_wc_initialize_order_details_controller');


/**
 * Initializes the General Routes Controller.
 * This controller registers other miscellaneous routes used by the syncerize App.
 *
 * @return void
 */
function syncerize_wc_initialize_general_routes_controller()
{
    $order_controller = new General_Routes_Controller();
    $order_controller->register_routes();
}

add_action('rest_api_init', 'syncerize_wc_initialize_general_routes_controller');

/**
 * This function adds an admin notice if there is
 * plugin activation issue
 */
function syncerize_wc_activation_error_notice()
{
    // Check if the error flag is set
    if (get_option('syncerize_wc_activation_error')) {
        echo '<div class="notice notice-error"><p>';
        _e(
            "There was an issue on plugin installation. Please reactivate plugin: 'Syncerize'",
            "syncerize-wc-textdomain"
        );
        echo '</p></div>';

        // Remove the option to only show the message once
        delete_option('syncerize_wc_activation_error');
    }
}

add_action('admin_notices', 'syncerize_wc_activation_error_notice');


/**
 * Get Syncerize_WC Config
 *
 * Fetches and caches the plugin's configuration data from the config file.
 *
 * @return array The configuration data.
 */
function syncerize_wc_get_config()
{
    static $config_syncerize = null;
    if ($config_syncerize === null) {
        $config_syncerize = include(plugin_dir_path(__FILE__) . 'config.php');
    }
    return $config_syncerize;
}

add_filter('site_transient_update_plugins', 'syncerize_wc_check_for_plugin_update');
add_filter('plugins_api', 'syncerize_wc_plugin_api_call', 10, 3);
add_filter('auto_update_plugin', '__return_true');
