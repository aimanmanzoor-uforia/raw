<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

return [
    // Example defaults — copy this file to config.php and adjust per environment

    /* For Dev */
    'APP_ID' => 420380673,
    'APP_ENV' => 'dev',
    'APP_URL' => 'https://dev.syncerize.com',
    'PLUGIN_UPDATE_URL' => 'https://syncerize.com/wp-content/uploads/Wordpress/dev/syncerize.json'
];
