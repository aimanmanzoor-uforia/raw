<?php

global $plugin_file_url;

// Function that registers the user to the syncerize app when the plugin is activated.
register_activation_hook($plugin_file_url, 'syncerize_wc_register_user_to_syncerize_app');

// Function that handles cleanup operations when the plugin is uninstalled.
register_uninstall_hook($plugin_file_url, 'syncerize_wc_plugin_uninstall');

/**
 * This hook triggers when a product is updated in WooCommerce.
 *
 * @param  int  $product_id  The ID of the Woocommerce product being updated.
 * @return void
 */
add_action('woocommerce_update_product', 'syncerize_wc_product_update');

/**
 * This hook triggers when a Variation is updated in WooCommerce.
 *
 * @param  object $product  The object of the Woocommerce product being updated.
 * @return void
 */
add_action('woocommerce_product_set_stock', 'syncerize_wc_track_inventory_stock');

add_action('woocommerce_variation_set_stock', 'syncerize_wc_track_inventory_stock');


/**
 * This hook triggers when a post is deleted in WooCommerce.
 *
 * @param  int  $post_id  The ID of the post being updated.
 * @return void
 */
add_action('wp_trash_post', 'syncerize_wc_product_delete');

/**
 * This hook triggers when order is created in WooCommerce.
 *
 * @param  int  $order_id  The ID of the Woocommerce order
 * @param  int  $order  Woocommerce order data
 * @return void
 */
add_action('woocommerce_new_order', 'syncerize_wc_order_create', 10, 2);

/**
 * This hook triggers when order is updated in WooCommerce.
 *
 * @param  int  $order_id  The ID of the Woocommerce order
 * @param  int  $order  Woocommerce order data
 * @return void
 */
//add_action('woocommerce_update_order', 'syncerize_wc_order_update', 10, 2);

/**
 * This hook triggers when order is deleted in WooCommerce.
 *
 * @param  int  $order_id  The ID of the Woocommerce order
 * @return void
 */
add_action('woocommerce_delete_order', 'syncerize_wc_order_delete');

/**
 * This hook triggers when an order status changes.
 * It allows the plugin to perform actions based on status updates.
 *
 * @param  int  $order_id  The ID of the WooCommerce order.
 * @param  string  $old_status  The old status of the order.
 * @param  string  $new_status  The new status of the order.
 * @return void
 */
add_action('woocommerce_order_status_changed', 'syncerize_wc_order_status_changed', 10, 3);

/**
 * This hook triggers when an order note is added in a order
 *
 * @param $comment_id
 * @param $order
 *
 * @return void
 */
add_action('woocommerce_order_note_added', 'syncerize_wc_order_note_added', 10, 3);

add_action(
    'woocommerce_product_before_set_stock',
    function ($product) {
        update_post_meta($product->get_id(), '_old_stock_quantity', $product->get_stock_quantity());
    }
);
