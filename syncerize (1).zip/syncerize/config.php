<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

return [
    /* For Dev */
    'APP_ID' => 420380673,
    'APP_ENV' => 'dev',
    'APP_URL' => 'https://dev.syncerize.com',
    'PLUGIN_UPDATE_URL' => 'https://syncerize.com/wp-content/uploads/Wordpress/dev/syncerize.json'

    /* For Staging */
//    'APP_ID' => 191712329729,
//    'APP_ENV' => 'staging',
//    'APP_URL' => 'https://staging-app.syncerize.com',
//    'PLUGIN_UPDATE_URL' => 'https://syncerize.com/wp-content/uploads/Wordpress/staging/syncerize.json'

    /* For Production */
//    'APP_ID' => 5456643,
//    'APP_ENV' => 'production',
//    'APP_URL' => 'https://v2-alpha.syncerize.com',
//    'PLUGIN_UPDATE_URL' => 'https://syncerize.com/wp-content/uploads/Wordpress/live/syncerize.json'
];