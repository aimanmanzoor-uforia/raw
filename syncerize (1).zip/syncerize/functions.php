<?php

if (!function_exists('syncerize_wc_log')) {
function syncerize_wc_log($message, $level = 'info', array $context = array())
{
    if (is_array($message) || is_object($message)) {
        $message = wp_json_encode($message);
    } elseif (!is_string($message)) {
        $message = strval($message);
    }

    if (function_exists('wc_get_logger')) {
        $logger = wc_get_logger();
        $context = array_merge(array('source' => 'syncerize'), $context);
        switch (strtolower($level)) {
            case 'emergency':
            case 'alert':
            case 'critical':
            case 'error':
                $logger->error($message, $context);
                break;
            case 'warning':
                $logger->warning($message, $context);
                break;
            case 'notice':
                $logger->notice($message, $context);
                break;
            case 'debug':
                $logger->debug($message, $context);
                break;
            case 'info':
            default:
                $logger->info($message, $context);
                break;
        }
    } else {
        // Fallback if WooCommerce logger is unavailable
        error_log('[syncerize][' . strtolower($level) . '] ' . $message);
    }
}
}

function syncerize_wc_get_shop()
{
    return preg_replace('#^https?://#', '', get_site_url());
}

/**
 * Retrieves the user ID associated with a given shop name.
 *
 * This function fetches the shop ID stored in the WordPress options table
 * for the specified shop name.
 *
 * @param  string  $shop_name  The name of the shop.
 *
 * @return mixed The shop ID or null if not found.
 */
function syncerize_wc_get_user_id_by_shop_name(string $shop_name)
{
    return get_option('_syncerize_' . $shop_name . '_shop_id');
}

/**
 * Encodes a string using URL-safe Base64 encoding.
 *
 * This function encodes the input string using Base64 and then replaces
 * characters that are not URL-safe
 * ('+' and '/') with URL-safe alternatives ('-' and '_'). It also removes any
 * trailing '=' characters.
 *
 * @param  string  $input  The string to be encoded.
 *
 * @return string The URL-safe Base64 encoded string.
 */
function syncerize_wc_base64_url_encode($input)
{
    return rtrim(strtr(base64_encode($input), '+/', '-_'), '=');
}

/**
 * Decodes a URL-safe Base64 encoded string.
 *
 * This function decodes a URL-safe Base64 encoded string by replacing URL-safe
 * characters ('-' and '_') with their original Base64 characters ('+' and
 * '/'). It also adds any necessary padding with '=' characters.
 *
 * @param  string  $input  The URL-safe Base64 encoded string to be decoded.
 *
 * @return string The decoded string.
 */
function syncerize_wc_base64_url_decode($data)
{
    $base64       = strtr($data, '-_', '+/');
    $base64Padded = str_pad($base64, strlen($base64) % 4, '=', STR_PAD_RIGHT);
    return base64_decode($base64Padded);
}

/**
 * Generates a unique ID by combining the current time in microseconds and a
 * random number.
 *
 * This function retrieves the current time with microsecond precision,
 * converts it to an integer by removing the decimal point, and appends a
 * randomly generated number within a specified range to ensure uniqueness.
 *
 * @return string A unique identifier string composed of the current time in
 *     microseconds and a random number.
 */
function syncerize_wc_generate_unique_id(): string
{
    // Get the current time in microseconds
    $timeInMicroseconds = microtime(true);

    // Convert the time to an integer by removing the decimal point
    $integerTime = str_replace('.', '', $timeInMicroseconds);

    // Ensure the integerTime is at least 9 digits long by padding with zeros if needed
    $integerTime = str_pad($integerTime, 9, '0', STR_PAD_RIGHT);

    // Take the first 9 digits of the integerTime
    $integerTime = substr($integerTime, 0, 9);

    // Generate a 4-digit random number
    $randomNumber = rand(1000, 9999);

    // Concatenate the 9-digit time-based integer and the 4-digit random number
    return $integerTime . $randomNumber;
}


/****** ....................Webhook Handling Starts.................... ******/

/**
 * Sends Webhook data to Syncerize App
 *
 * @param $topic
 * @param $payload
 *
 * @return mixed
 */
function syncerize_wc_send_webhook_to_syncerize_app($topic, $payload)
{
    global $config_syncerize, $shop;

    $config_syncerize = empty($config_syncerize) ? syncerize_wc_get_config() : $config_syncerize;
    $shop             = empty($shop) ? syncerize_wc_get_shop() : $shop;

    // Create Webhook ID
    $webhookId = syncerize_wc_generate_unique_id();

    // Endpoint URL
    $endpoint_url = $config_syncerize["APP_URL"] . '/woocommerce-webhook';
    $body         = (object)$payload;
    $args         = [
        'method' => 'POST',
        'sslverify' => false,
        'body' => json_encode($body),
        'headers' => [
            'X-Woocommerce-Topic' => $topic,
            'X-Woocommerce-Shop-Domain' => "$shop",
            'X-Woocommerce-Webhook-Id' => "$webhookId",
            'Content-Type' => 'application/json',
            'User-Agent' => 'Syncerize/1.0; ' . get_bloginfo('url'),
        ],
    ];

    // Make a POST request to the endpoint
    return wp_remote_post($endpoint_url, $args);
}

/**
 * Registers the current user with the Syncerize app.
 *
 * This function sends a request to the Syncerize API to register the
 * current user. On success, it stores the returned shop ID and Password
 * in the WordPress options table.
 *
 * @return void
 */
function syncerize_wc_register_user_to_syncerize_app()
{
    syncerize_wc_log('plugin activation hook called....................');
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(__('Syncerize requires WooCommerce to be installed and active.', 'syncerize'));
    }

    $config_syncerize = syncerize_wc_get_config();

    $current_user = wp_get_current_user();

    if ($current_user->ID === 0) {
        syncerize_wc_log('No user is currently logged in.', 'warning');
        return;
    }
    $email     = $current_user->data->user_email;
    $shopName  = syncerize_wc_get_shop();
    $shopTitle = get_bloginfo('name');

    // Prepare the data for the API request
    $api_url = $config_syncerize["APP_URL"] . '/api/woocommerce-register-user'; // You can save the URL in the options table
    $body    = array(
        'name' => $shopName,
        'title' => $shopTitle,
        'email' => $email
    );

    $response = wp_remote_post(
        $api_url,
        array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'User-Agent' => 'Syncerize/1.0; ' . get_bloginfo('url'),
            ),
            'body' => json_encode($body),
            'timeout' => 60,
        )
    );

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        syncerize_wc_log("User registration failed: $error_message", 'error');
    } else {
        $response_body = wp_remote_retrieve_body($response);
        $response_body = json_decode($response_body);
        $user_details  = $response_body->user;

        update_option('_syncerize_' . $user_details->name . '_shop_id', $user_details->id);

        // Generate a salt using a hash of the email and shop domain
        $salt = substr(sha1($email . $shopName), 0, 16);
        // Generate the password using crypt() with a salt
        $userPassword = 'wcat_' . crypt($email . $shopName, '$6$' . $salt); // $6$ indicates SHA-512 hash

        update_option('_syncerize_' . $user_details->name . '_shop_password', $userPassword);
        syncerize_wc_log('User registered successfully: ' . json_encode($response_body));
    }
}


/**
 * Handles plugin uninstallation.
 *
 * This function is called when the plugin is uninstalled. It sends a
 * POST request to the Laravel application indicating that the app has
 * been uninstalled, and cleans up the plugin's stored data.
 *
 * @return void
 */
function syncerize_wc_plugin_uninstall()
{
    try {
        syncerize_wc_log('plugin uninstallation hook called....................');
        $shopName = syncerize_wc_get_shop();

        $current_user = wp_get_current_user();
        if ($current_user->ID === 0) {
            syncerize_wc_log('No user is currently logged in.', 'warning');
            return;
        }
        $email = $current_user->data->user_email;

        $shopTitle = get_bloginfo('name');

        // Prepare the data for the API request
        $shop_data        = new stdClass();
        $shop_data->name  = $shopName;
        $shop_data->title = $shopTitle;
        $shop_data->email = $email;

        // Sending curl request
        $response = syncerize_wc_send_webhook_to_syncerize_app('app-uninstalled', $shop_data);

        // Request failed, handle the error
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            syncerize_wc_log('App Uninstall Webhook failed..', 'error');
            syncerize_wc_log($error_message, 'error');
        }

        // Clean up the user data stored in the WordPress options table
        delete_option('_syncerize_' . $shopName . '_shop_id');
        delete_option('_syncerize_' . $shopName . '_shop_password');
        delete_option('_syncerize_' . $shopName . '_shop_type');
    } catch (Exception $e) {
        syncerize_wc_log('App Uninstall Webhook failed...', 'error');
        syncerize_wc_log($e->getMessage(), 'error');
    }
}

/**
 * Sends Product update webhook data to Syncerize App.
 *
 * This function is triggered when a WooCommerce product is updated.
 * It retrieves product details, formats the data for Shopify, and sends
 * a POST request to update the product information on a connected store.
 *
 * @param  int  $product_id  The ID of the updated product.
 *
 * @return void|WP_Error Returns a WP_Error if the product is not found.
 */
function syncerize_wc_product_update(int $product_id)
{
    try {
        // Create a new WP_REST_Request object
        $request = new WP_REST_Request('GET', '/swc/v1/fetch-product');

        // Set parameters for the request
        $request->set_param('productId', syncerize_wc_generate_resource_id('product', $product_id));

        // Call the fetch_product_details function with the request object
        $product_controller    = new \Syncerize\WooCommerce\Product_Details_Controller();
        $product_data_response = $product_controller->fetch_product($request);

        // Convert the WP_REST_Response object to a plain array
        if (is_wp_error($product_data_response)) {
            return $product_data_response->get_error_messages();
        } else {
            $product_data_response = $product_data_response->get_data();
        }

        if ($product_data_response['errors']) {
            // Product not found
            syncerize_wc_log('Product not found..', 'warning');
            return;
        }
        $product_data = $product_data_response['body']['container']['data']['product'];

        // Sending curl request
        $response = syncerize_wc_send_webhook_to_syncerize_app('products-update', $product_data);

        // Request failed, handle the error
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            syncerize_wc_log('Product Update Webhook failed..', 'error');
            syncerize_wc_log($error_message, 'error');
        }
    } catch (Exception $e) {
        syncerize_wc_log('Product update webhook called...', 'error');
        syncerize_wc_log($e->getMessage(), 'error');
    }
}

function syncerize_wc_track_inventory_stock($product)
{
    try {
        error_log('syncerize_wc_track_inventory_stock called ');
        $variant_id = syncerize_wc_generate_resource_id('variant', $product->get_id());

        // Prepare payload for webhook
        $product_data = new stdClass();
        $product_data->inventory_item_id = $variant_id;
        error_log('Inventory Item ID: ' . $product_data->inventory_item_id);

        // Sending curl request
        $response = syncerize_wc_send_webhook_to_syncerize_app('inventory_levels-update', $product_data);

        // Request failed, handle the error
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            syncerize_wc_log('track inventory stock failed..', 'error');
            syncerize_wc_log($error_message, 'error');
        }

    } catch (Exception $e) {
        syncerize_wc_log('track inventory stock called...', 'error');
        syncerize_wc_log($e->getMessage(), 'error');
    }
}


/**
 * Sends Product delete webhook data to Syncerize App.
 *
 * This function is triggered when a post is deleted.
 * It retrieves product details, formats the data for Shopify, and sends
 * a POST request to delete the product information on a connected store.
 *
 * @param  int  $post_id  The ID of the post.
 *
 * @return void
 */
function syncerize_wc_product_delete(int $post_id)
{
    if (get_post_type($post_id) === 'product') {
        $product_id = $post_id;

        syncerize_wc_log('Product delete webhook called........');

        try {
            $product_data     = new stdClass();
            $product_data->id = syncerize_wc_generate_resource_id('product', $product_id);

            // Sending curl request
            $response = syncerize_wc_send_webhook_to_syncerize_app('products-delete', $product_data);

            // Request failed, handle the error
            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                syncerize_wc_log('Product Delete Webhook failed..', 'error');
                syncerize_wc_log($error_message, 'error');
            }
        } catch (Exception $e) {
            syncerize_wc_log('Product update webhook called...', 'error');
            syncerize_wc_log($e->getMessage(), 'error');
        }
    }
}

/**
 * Sends Order create webhook data to Syncerize App.
 *
 * This function retrieves order details from WooCommerce, shapes the data
 * according to Shopify requirements, and sends a POST request to a specified
 * Shopify webhook endpoint with the order data.
 *
 * @param $order_id  The WooCommerce order ID.
 * @param  $order  The WooCommerce order data.
 */
function syncerize_wc_order_create($order_id, $order)
{
    syncerize_wc_log('Order Create webhook called........');
    try {
        // Create a new WP_REST_Request object
        $request = new WP_REST_Request('GET', '/swc/v1/fetch-order/');

        // Set parameters for the request
        $request->set_param('orderId', syncerize_wc_generate_resource_id('order', $order_id));

        // Call the fetch_order_details function with the request object
        $order_controller    = new \Syncerize\WooCommerce\Order_Details_Controller();
        $order_data_response = $order_controller->fetch_order_details($request);

        // Convert the WP_REST_Response object to a plain array
        if (is_wp_error($order_data_response)) {
            return $order_data_response->get_error_messages();
        } else {
            $order_data_response = $order_data_response->get_data();
        }
        syncerize_wc_log('$order_data_response: ' . json_encode($order_data_response));

        if ($order_data_response['errors']) {
            // Order not found
            syncerize_wc_log('Order not found..');
            return;
        }
        $order_data = $order_data_response['body']['order'];

        syncerize_wc_log('$order_data: ' . json_encode($order_data));

        // Sending curl request
        $response = syncerize_wc_send_webhook_to_syncerize_app('orders-create', $order_data);

        // Request failed, handle the error
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            syncerize_wc_log('Order Create Webhook failed..');
            syncerize_wc_log($error_message);
        } else {
            // Mark the order as dispatched
            update_post_meta($order_id, '_order_create_job_dispatched', true);
        }
    } catch (Exception $e) {
        syncerize_wc_log("Order Create webhook called (ID:$order_id)...");
        syncerize_wc_log($e->getMessage());
    }
}

/**
 * Sends Order update webhook data to Syncerize App.
 *
 * This function retrieves order details from WooCommerce, shapes the data
 * according to Shopify requirements, and sends a POST request to a specified
 * Shopify webhook endpoint with the order data.
 *
 * @param  int  $order_id  The WooCommerce order ID.
 * @param  int  $order  The WooCommerce order data.
 */
/*function syncerize_wc_order_update($order_id, $order)
{
    syncerize_wc_log('Order Update webhook called........');
    try {
        // Create a new WP_REST_Request object
        $request = new WP_REST_Request('GET', '/swc/v1/fetch-order/');

        // Set parameters for the request
        $request->set_param('orderId', syncerize_wc_generate_resource_id('order', $order_id));

        // Call the fetch_order_details function with the request object
        $order_controller    = new \Syncerize\WooCommerce\Order_Details_Controller();
        $order_data_response = $order_controller->fetch_order_details($request);

        // Convert the WP_REST_Response object to a plain array
        if (is_wp_error($order_data_response)) {
            return $order_data_response->get_error_messages();
        } else {
            $order_data_response = $order_data_response->get_data();
        }
        syncerize_wc_log('$order_data_response: ' . json_encode($order_data_response));

        if ($order_data_response['errors']) {
            // Order not found
            syncerize_wc_log('Order not found..');
            return;
        }
        $order_data = $order_data_response['body']['order'];

        syncerize_wc_log('$order_data: ' . json_encode($order_data));

        // Sending curl request
        $response = syncerize_wc_send_webhook_to_syncerize_app('orders-updated', $order_data);

        // Request failed, handle the error
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            syncerize_wc_log('Order Update Webhook failed..');
            syncerize_wc_log($error_message);
        }

    } catch (Exception $e) {
        syncerize_wc_log('Order Update webhook called...');
        syncerize_wc_log($e->getMessage());
    }
}*/

/**
 * Sends Order delete webhook data to Syncerize App.
 *
 * This function retrieves order details from WooCommerce, shapes the data
 * according to Shopify requirements, and sends a POST request to a specified
 * Shopify webhook endpoint with the order data.
 *
 * @param  int  $order_id  The WooCommerce order ID.
 */
function syncerize_wc_order_delete($order_id)
{
    syncerize_wc_log('Order Delete webhook called........');
    try {
        $order_data     = new stdClass();
        $order_data->id = syncerize_wc_generate_resource_id('order', $order_id);

        // Sending curl request
        $response = syncerize_wc_send_webhook_to_syncerize_app('orders-delete', $order_data);

        // Request failed, handle the error
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            syncerize_wc_log('Order Delete Webhook failed..');
            syncerize_wc_log($error_message);
        }
    } catch (Exception $e) {
        syncerize_wc_log('Order Delete webhook called...');
        syncerize_wc_log($e->getMessage());
    }
}

/**
 * Sends Order cancel/fulfilled webhook data to Syncerize App.
 *
 * This function retrieves order details from WooCommerce, shapes the data
 * according to Shopify requirements, and sends a POST request to a specified
 * Shopify webhook endpoint with the order data.
 *
 * @param  $order_id
 * @param  $old_status
 * @param  $new_status
 *
 * @return void
 */
function syncerize_wc_order_status_changed($order_id, $old_status, $new_status)
{
    syncerize_wc_log('Order Status change webhook called........');
    try {
        syncerize_wc_log('$old_status----: ' . $old_status);
        syncerize_wc_log('$new_status----: ' . $new_status);

        // If order is cancelled
        if ($new_status == 'cancelled') {
            $topic = 'orders-cancelled';
        } elseif ($new_status == 'completed') {  // If order is completed/fulfilled
            $topic = 'orders-fulfilled';
        } elseif (($old_status == 'pending' || $old_status == 'failed') && $new_status == 'processing') {  // If order is paid
            syncerize_wc_log('in payment processed........................');
            $topic = 'orders-updated';
        } else {
            return;
        }

        // If order create job is not dispatched yet, then send order create webhook instead of current order webhook
        $topic = get_post_meta($order_id, '_order_create_job_dispatched', true) ? $topic : 'orders-create';

        syncerize_wc_log(
            "order_create_job_dispatched_$order_id: " . get_post_meta($order_id, '_order_create_job_dispatched', true)
        );

        // Create a new WP_REST_Request object
        $request = new WP_REST_Request('GET', '/swc/v1/fetch-order/');

        // Set parameters for the request
        $request->set_param('orderId', syncerize_wc_generate_resource_id('order', $order_id));

        // Call the fetch_order_details function with the request object
        $order_controller    = new \Syncerize\WooCommerce\Order_Details_Controller();
        $order_data_response = $order_controller->fetch_order_details($request);

        // Convert the WP_REST_Response object to a plain array
        if (is_wp_error($order_data_response)) {
            return $order_data_response->get_error_messages();
        } else {
            $order_data_response = $order_data_response->get_data();
        }

        syncerize_wc_log('$order_data_response: ' . json_encode($order_data_response));

        if ($order_data_response['errors']) {
            // Order not found
            syncerize_wc_log('Order not found..');
            return;
        }

        $order_data = $order_data_response['body']['order'];

        // Sending curl request
        $response = syncerize_wc_send_webhook_to_syncerize_app($topic, $order_data);

        // Request failed, handle the error
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            syncerize_wc_log('Order Status change webhook failed..');
            syncerize_wc_log($error_message);
        } elseif ($topic == 'orders-create') {
            // Mark order create job as dispatched
            update_post_meta($order_id, '_order_create_job_dispatched', true);
        }
    } catch (Exception $e) {
        syncerize_wc_log("Order Status change webhook called (ID:$order_id)...");
        syncerize_wc_log($e->getMessage());
    }
}

/**
 * This function is triggered when order note is added
 * it triggers source order update
 *
 * @param $comment_id
 * @param $order
 *
 * @return void
 */
function syncerize_wc_order_note_added($comment_id, $order)
{
    syncerize_wc_log('Order Update webhook via order note called........');

    try {
        // Return if notes added from Syncerize
        if (defined('REST_REQUEST') && REST_REQUEST) {
            syncerize_wc_log('Notes added from Syncerize.');
            return;
        }

        global $shop;

        $shop = empty($shop) ? syncerize_wc_get_shop() : $shop;

        // Get store type
        $storeType = get_option('_syncerize_' . $shop . '_shop_type');

        // Return if store type empty or if its destination store
        if (empty($storeType) || $storeType == 'client') {
            syncerize_wc_log('Notes Added: Store type empty or destination store.');
            return;
        }

        // Get the order note object
        $note = wc_get_order_note($comment_id);

        if (!$note) {
            syncerize_wc_log('Order Note not found.');
            return; // Exit if no note found
        }

        // Check if the note is not system-generated
        if (preg_match('/Order status changed|Added line items|Stock levels reduced/', $note->content)) {
            return;
        }

        // Create a new WP_REST_Request object
        $request = new WP_REST_Request('GET', '/swc/v1/fetch-order/');

        // Set parameters for the request
        $request->set_param('orderId', syncerize_wc_generate_resource_id('order', $order->get_id()));

        // Call the fetch_order_details function with the request object
        $order_controller    = new \Syncerize\WooCommerce\Order_Details_Controller();
        $order_data_response = $order_controller->fetch_order_details($request);

        // Convert the WP_REST_Response object to a plain array
        if (is_wp_error($order_data_response)) {
            return $order_data_response->get_error_messages();
        } else {
            $order_data_response = $order_data_response->get_data();
        }

        syncerize_wc_log('$order_data_response: ' . json_encode($order_data_response));

        if ($order_data_response['errors']) {
            // Order not found
            syncerize_wc_log('Order not found.');
            return;
        }

        $order_data = $order_data_response['body']['order'];

        syncerize_wc_log('$order_data: ' . json_encode($order_data));

        // Sending curl request for Orders Update job
        $response = syncerize_wc_send_webhook_to_syncerize_app('orders-updated', $order_data);

        // Request failed, handle the error
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            syncerize_wc_log('Order Update Webhook failed..');
            syncerize_wc_log($error_message);
        }
    } catch (Exception $e) {
        syncerize_wc_log('Order Update webhook called...');
        syncerize_wc_log($e->getMessage());
    }
}


/****** ....................Webhook Handling Ends.................... ******/

/**
 * This function is used get the object modified at
 * datetime in UTC
 *
 * @param $object
 * @return mixed
 */
function syncerize_wc_get_object_modified_at_datetime_in_utc($object)
{
    // Step 1: Get the modified date as a DateTime object
    $date = $object->get_date_modified(); // This should already be a DateTime object

    // Step 2: Convert to UTC timezone
    $date->setTimezone(new DateTimeZone('UTC'));

    // Step 3: Format it
    return $date->format('Y-m-d\TH:i:sP');
}

/**
 * Adds the Syncerize admin menu in the WordPress dashboard.
 *
 * This function creates a main menu and submenus for the Syncerize plugin
 * in the WordPress admin area. It checks the user's plan ID to conditionally
 * display certain submenus.
 *
 * @return void
 */
function syncerize_wc_syncerize_add_admin_menu()
{
    global $submenu, $config_syncerize, $shop;

    $config_syncerize = empty($config_syncerize) ? syncerize_wc_get_config() : $config_syncerize;
    $shop             = empty($shop) ? syncerize_wc_get_shop() : $shop;
    // Get store type
    $storeType = get_option('_syncerize_' . $shop . '_shop_type');

    add_menu_page(
        'Syncerize', // Page title
        'Syncerize', // Menu title
        'manage_options', // Capability
        'syncerize-admin', // Menu slug
        'syncerize_wc_syncerize_render_admin_page', // Callback function
        'dashicons-update', // Icon URL
        6 // Position
    );

    add_submenu_page(
        'syncerize-admin', // Parent slug
        'Syncerize Dashboard', // Page title
        'Dashboard', // Menu title
        'manage_options', // Capability
        'syncerize-dashboard', // Menu slug
        'syncerize_wc_syncerize_render_admin_page' // Callback function
    );

    // Check if store type is empty
    if (!empty($storeType)) {
        add_submenu_page(
            'syncerize-admin', // Parent slug
            'Syncerize Stores', // Page title
            'Stores', // Menu title
            'manage_options', // Capability
            'syncerize-stores', // Menu slug
            'syncerize_wc_syncerize_render_admin_page' // Callback function
        );

        add_submenu_page(
            'syncerize-admin', // Parent slug
            'Syncerize Products', // Page title
            'Products', // Menu title
            'manage_options', // Capability
            'syncerize-products', // Menu slug
            'syncerize_wc_syncerize_render_admin_page' // Callback function
        );

        add_submenu_page(
            'syncerize-admin', // Parent slug
            'Syncerize Orders', // Page title
            'Orders', // Menu title
            'manage_options', // Capability
            'syncerize-orders', // Menu slug
            'syncerize_wc_syncerize_render_admin_page' // Callback function
        );

        add_submenu_page(
            'syncerize-admin', // Parent slug
            'Syncerize Notifications', // Page title
            'Notifications', // Menu title
            'manage_options', // Capability
            'syncerize-notifications', // Menu slug
            'syncerize_wc_syncerize_render_admin_page' // Callback function
        );

        if ($storeType == 'client') {
            add_submenu_page(
                    'syncerize-admin', // Parent slug
                    'Syncerize Plans', // Page title
                    'Plans', // Menu title
                    'manage_options', // Capability
                    'syncerize-plans', // Menu slug
                    'syncerize_wc_syncerize_render_admin_page' // Callback function
            );
        }

        add_submenu_page(
            'syncerize-admin', // Parent slug
            'Syncerize Settings', // Page title
            'Settings', // Menu title
            'manage_options', // Capability
            'syncerize-settings', // Menu slug
            'syncerize_wc_syncerize_render_admin_page' // Callback function
        );
    }

    // Removing Main menu repetition
    unset($submenu['syncerize-admin'][0]);
}

/**
 * Renders the admin page for the Syncerize plugin.
 *
 * This function generates the HTML for the Syncerize admin page, including
 * an iframe that loads the app. It checks for the presence of an
 * authentication token and fetches it if necessary.
 *
 * @return void
 */
function syncerize_wc_syncerize_render_admin_page()
{
    global $config_syncerize;
    $current_screen = get_current_screen();

    switch ($current_screen->base) {
        case 'syncerize_page_syncerize-stores':
            $url = '/app/stores';
            break;
        case 'syncerize_page_syncerize-products':
            $url = '/app/products';
            break;
        case 'syncerize_page_syncerize-orders':
            $url = '/app/orders';
            break;
        case 'syncerize_page_syncerize-notifications':
            $url = '/app/notifications';
            break;
        case 'syncerize_page_syncerize-plans':
            $url = '/app/plans';
            break;
        case 'syncerize_page_syncerize-settings':
            $url = '/app/settings';
            break;
        default:
            $url = '/';
            break;
    }

    $shop = syncerize_wc_get_shop();

    $shopId    = syncerize_wc_get_user_id_by_shop_name($shop);
    $shopPassw = get_option('_syncerize_' . $shop . '_shop_password');
    if (empty($shopId) || empty($shopPassw)) {
        // Store a flag to trigger the admin notice on the next page load
        add_option('syncerize_wc_activation_error', true);

        // Redirect to the plugins page
        wp_redirect(admin_url('plugins.php'));
        exit;
    }

    // Generate a JWT token
    $payload = [
        "user_id" => $shopId,
        "username" => $shop,
        "exp" => time() + 150, // Token expiration time (2.5 min)
    ];
    $token   = syncerize_wc_create_jwt_token($payload, $shopPassw);

    // Open app in Iframe with necessary query params
    $currentSite = get_site_url();
    $url         = $config_syncerize["APP_URL"] . $url . "?token=$token&store=$shop&ancestor=$currentSite&platform=woocommerce";
    ?>

    <div class="wrap">
        <iframe src="<?php
        echo $url ?>" width="100%" style="border: none; height: 94vh"
                allow="clipboard-read; clipboard-write"></iframe>
    </div>
    <?php
}

/**
 * Creates JWT Token
 *
 * @param  $payload
 * @param  $secretKey
 *
 * @return string The decoded string.
 */
function syncerize_wc_create_jwt_token($payload, $secretKey)
{
    $base64UrlHeader    = syncerize_wc_base64_url_encode(json_encode(["alg" => "HS256", "typ" => "JWT"]));
    $base64UrlPayload   = syncerize_wc_base64_url_encode(json_encode($payload));
    $base64UrlSignature = hash_hmac('sha256', $base64UrlHeader . '.' . $base64UrlPayload, $secretKey, true);
    $base64UrlSignature = syncerize_wc_base64_url_encode($base64UrlSignature);

    return $base64UrlHeader . '.' . $base64UrlPayload . '.' . $base64UrlSignature;
}

/**
 * Validates JWT Token
 *
 * @param  string  $token
 * @param  string  $userPassw
 *
 * @return bool The decoded string.
 */
function syncerize_wc_validate_token($token, $userPassw)
{
    // Implementation for validating JWT
    list($base64UrlHeader, $base64UrlPayload, $base64UrlSignature) = explode('.', $token);

    $signature         = syncerize_wc_base64_url_decode($base64UrlSignature);
    $expectedSignature = hash_hmac('sha256', $base64UrlHeader . '.' . $base64UrlPayload, $userPassw, true);

    return hash_equals($signature, $expectedSignature);
}

/**
 * Generates unique id for syncerize
 *
 * This will generate unique number for resource(Product,Variant,Image,Order..etc)
 * combining Prefix (4 digit) + Resource Type ID (2 digit) + Shop ID (6 digit) + Resource ID (unlimited)
 *
 * @param  $resource_type
 * @param  $resource_id
 *
 * @return string
 */
function syncerize_wc_generate_resource_id($resource_type, $resource_id): string
{
    global $shop;

    // Define Resource Types with 2-digit IDs
    $resource_types = [
        'product' => '01',
        'order' => '02',
        'variant' => '03',
        'image' => '04',
        'option' => '05',
        'metafield' => '06',
        'draftOrder' => '07',
        'customer' => '08',
        'media' => '09',
        'lineItem' => '10'
    ];

    // Set the Prefix
    $prefix = '4444';

    // Get the 2-digit Resource Type ID
    $resource_type_id = $resource_types[$resource_type];

    // Fetch shop ID and pad to 6 digits
    $shop_id = syncerize_wc_get_user_id_by_shop_name($shop);
    $shop_id = str_pad($shop_id, 6, '0', STR_PAD_LEFT);

    // No limit on the number of digits in $resource_id, but ensure it is a string
    $resource_id = (string)$resource_id;

    // Return the formatted Resource ID
    return $prefix . $resource_type_id . $shop_id . $resource_id;
}

/**
 * Decode resource id for wordpress
 *
 * This will extract the ResourceID by skipping the first 12 characters
 * (4 for prefix, 2 for ResourceType, 6 for StoreID)
 *
 * @param  $resource_id
 *
 * @return int
 */
function syncerize_wc_decode_resource_id($resource_id): int
{
    // Extract the ResourceID by skipping the first 12 characters (4 for prefix, 2 for ResourceType, 6 for StoreID)
    $resource_id = substr($resource_id, 12);

    // Convert to integer to remove any leading zeros
    return (int)$resource_id;
}

/**
 * Converts number to 2 decimal digit
 *
 *
 * @param  $value
 *
 * @return string
 */
function syncerize_wc_convert_number_format($value): string
{
    return number_format($value, 2, '.', '');
}

/**
 * This function gets product id based on barcode
 *
 * @param $unique_code
 * @return null
 */
function syncerize_wc_get_product_id_by_barcode($unique_code)
{
    if (empty($unique_code)) {
        return null;
    }

    $post_type = ['product_variation', 'product'];

    $args = [
        'post_type' => $post_type,
        'meta_key' => '_global_unique_id',
        'post_status' => ['publish'],
        'meta_value' => $unique_code,
        'posts_per_page' => 1,
        'fields' => 'ids'
    ];

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        return $query->posts[0];
    }

    // No product found with the specified meta value
    return null;
}

/**
 * This function checks if the barcode format is compatible for
 * woocommerce to save in a product
 *
 * @param $value
 *
 * @return bool
 */
function syncerize_wc_is_barcode_format_compatible($value): bool
{
    if (preg_match('/^[\d-]+$/', $value ?? "")) {
        return true;
    }

    return false;
}

/**
 * Function converts shopify gid to integer id
 *
 * @param $id
 */
function syncerize_wc_convert_gid_to_id(&$id)
{
    $array = explode('/', $id);

    $id = (int)end($array);
}

/**
 * This function returns endpoint error response
 *
 * @param $exception
 * @return mixed
 */
function syncerize_wc_error_response($exception)
{
    return rest_ensure_response(
        [
            'errors' => true,
            'status' => 500,
            'exception' => [
                'message' => $exception->getMessage(),
                'code' => $exception->getCode(),
                'file' => $exception->getFile(),
                'line' => $exception->getLine(),
                'trace' => $exception->getTraceAsString()
            ]
        ]
    );
}
