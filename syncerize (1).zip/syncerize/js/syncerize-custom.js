window.addEventListener('message', function (event) {
    if (event.data === 'syncerize_wc_reload') {
        window.location.reload();
    }
});