# Change Log

All notable changes to this project will be documented in this file.

## [1.2.26] - 2025-11-26

### Fixed

- Deleted variant on Shopify (source) not removed from WooCommerce (destination)
- Incorrect Error Shown During Single Syncing of a Product Having Duplicate Variant SKU/Barcode
- Product Mapping Failure Due to Attribute Limit Mismatch (WooCommerce to Shopify)


## [1.2.5] - 2025-06-17

### Changed

- Deprecating the Ability to Set Available Quantities on Already Active States on the InventoryActivate GraphQL Mutation

### Fixed

- WooCommerce to Shopify: Product Metafield Values Not Syncing


## [1.2.3] - 2025-06-03

### Added

- System-Generated Tags to Mapped Products

### Changed

- Code improvements for better maintainability

### Fixed

- Sync tag-issue
- Shopify Simple Product to WooCommerce Variable – Variants Not Updating


## [1.2.1] - 2025-05-06

### Changed

- PSR-12 complaint
- Functions name & placement

### Fixed

- Product Status Not updating from Woo(Source) to Woo(Destination) and Woo(Source) to Shopify(Destination)
- Static config naming conventions conflicts
- Class naming conventions conflicts

### Removed

- Extra logging
- Unused code

## [1.1.34] - 2025-03-26

### Added

- Inform User to Install WooCommerce Plugin Before Syncerize
- Implement re-ordering during image syncing

### Changed

### Fixed

- Dashboard Navigation Issue During Onboarding in WooCommerce
- Product Images Not Displaying on Destination Store of Syncerize-- Woocommerce



